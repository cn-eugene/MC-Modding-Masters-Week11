
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.elivanderlip.init;

import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.event.BuildCreativeModeTabContentsEvent;

import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.core.registries.Registries;

import net.mcreator.elivanderlip.EliVanderlipMod;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD)
public class EliVanderlipModTabs {
	public static final DeferredRegister<CreativeModeTab> REGISTRY = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, EliVanderlipMod.MODID);

	@SubscribeEvent
	public static void buildTabContentsVanilla(BuildCreativeModeTabContentsEvent tabData) {
		if (tabData.getTabKey() == CreativeModeTabs.BUILDING_BLOCKS) {
			tabData.accept(EliVanderlipModBlocks.NOTNT.get().asItem());
		} else if (tabData.getTabKey() == CreativeModeTabs.COMBAT) {
			tabData.accept(EliVanderlipModItems.CHICKEN.get());
			tabData.accept(EliVanderlipModItems.SUS_HELMET.get());
			tabData.accept(EliVanderlipModItems.MUSTERD.get());
			tabData.accept(EliVanderlipModItems.MASTER.get());
			tabData.accept(EliVanderlipModItems.SCYTHE.get());
			tabData.accept(EliVanderlipModItems.ENDMOUTH.get());
			tabData.accept(EliVanderlipModItems.VS_5HG.get());
			tabData.accept(EliVanderlipModItems.GUN.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.SPAWN_EGGS) {
			tabData.accept(EliVanderlipModItems.SKBDI_SPAWN_EGG.get());
			tabData.accept(EliVanderlipModItems.PLANE_SPAWN_EGG.get());
			tabData.accept(EliVanderlipModItems.WARIOR_SPAWN_EGG.get());
			tabData.accept(EliVanderlipModItems.SPIKE_SPAWN_EGG.get());
			tabData.accept(EliVanderlipModItems.HEROBRAIN_SPAWN_EGG.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.TOOLS_AND_UTILITIES) {
			tabData.accept(EliVanderlipModItems.MCD.get());
			tabData.accept(EliVanderlipModBlocks.TNT.get().asItem());
			tabData.accept(EliVanderlipModItems.SDC.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.NATURAL_BLOCKS) {
			tabData.accept(EliVanderlipModBlocks.CHICKENN.get().asItem());
			tabData.accept(EliVanderlipModBlocks.EYES.get().asItem());
		}
	}
}

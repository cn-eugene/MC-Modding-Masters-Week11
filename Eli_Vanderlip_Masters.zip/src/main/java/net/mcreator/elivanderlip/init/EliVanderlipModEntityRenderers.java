
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.elivanderlip.init;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.api.distmarker.Dist;

import net.minecraft.client.renderer.entity.ThrownItemRenderer;

import net.mcreator.elivanderlip.client.renderer.WariorRenderer;
import net.mcreator.elivanderlip.client.renderer.SpikeRenderer;
import net.mcreator.elivanderlip.client.renderer.SkbdiRenderer;
import net.mcreator.elivanderlip.client.renderer.PlaneRenderer;
import net.mcreator.elivanderlip.client.renderer.HerobrainRenderer;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public class EliVanderlipModEntityRenderers {
	@SubscribeEvent
	public static void registerEntityRenderers(EntityRenderersEvent.RegisterRenderers event) {
		event.registerEntityRenderer(EliVanderlipModEntities.SKBDI.get(), SkbdiRenderer::new);
		event.registerEntityRenderer(EliVanderlipModEntities.PLANE.get(), PlaneRenderer::new);
		event.registerEntityRenderer(EliVanderlipModEntities.MUST.get(), ThrownItemRenderer::new);
		event.registerEntityRenderer(EliVanderlipModEntities.TNTWD.get(), ThrownItemRenderer::new);
		event.registerEntityRenderer(EliVanderlipModEntities.BULLET.get(), ThrownItemRenderer::new);
		event.registerEntityRenderer(EliVanderlipModEntities.WARIOR.get(), WariorRenderer::new);
		event.registerEntityRenderer(EliVanderlipModEntities.SPIKE.get(), SpikeRenderer::new);
		event.registerEntityRenderer(EliVanderlipModEntities.HEROBRAIN.get(), HerobrainRenderer::new);
	}
}

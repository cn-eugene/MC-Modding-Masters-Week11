
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.elivanderlip.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.level.block.Block;

import net.mcreator.elivanderlip.block.TntBlock;
import net.mcreator.elivanderlip.block.SdcPortalBlock;
import net.mcreator.elivanderlip.block.NotntBlock;
import net.mcreator.elivanderlip.block.McdPortalBlock;
import net.mcreator.elivanderlip.block.EyesBlock;
import net.mcreator.elivanderlip.block.ChickennBlock;
import net.mcreator.elivanderlip.EliVanderlipMod;

public class EliVanderlipModBlocks {
	public static final DeferredRegister<Block> REGISTRY = DeferredRegister.create(ForgeRegistries.BLOCKS, EliVanderlipMod.MODID);
	public static final RegistryObject<Block> MCD_PORTAL = REGISTRY.register("mcd_portal", () -> new McdPortalBlock());
	public static final RegistryObject<Block> CHICKENN = REGISTRY.register("chickenn", () -> new ChickennBlock());
	public static final RegistryObject<Block> TNT = REGISTRY.register("tnt", () -> new TntBlock());
	public static final RegistryObject<Block> NOTNT = REGISTRY.register("notnt", () -> new NotntBlock());
	public static final RegistryObject<Block> EYES = REGISTRY.register("eyes", () -> new EyesBlock());
	public static final RegistryObject<Block> SDC_PORTAL = REGISTRY.register("sdc_portal", () -> new SdcPortalBlock());
	// Start of user code block custom blocks
	// End of user code block custom blocks
}


/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.elivanderlip.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.effect.MobEffect;

import net.mcreator.elivanderlip.potion.LightingMobEffect;
import net.mcreator.elivanderlip.potion.DvsdjxzcMobEffect;
import net.mcreator.elivanderlip.EliVanderlipMod;

public class EliVanderlipModMobEffects {
	public static final DeferredRegister<MobEffect> REGISTRY = DeferredRegister.create(ForgeRegistries.MOB_EFFECTS, EliVanderlipMod.MODID);
	public static final RegistryObject<MobEffect> DVSDJXZC = REGISTRY.register("dvsdjxzc", () -> new DvsdjxzcMobEffect());
	public static final RegistryObject<MobEffect> LIGHTING = REGISTRY.register("lighting", () -> new LightingMobEffect());
}


/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.elivanderlip.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.event.entity.EntityAttributeCreationEvent;

import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Entity;

import net.mcreator.elivanderlip.entity.WariorEntity;
import net.mcreator.elivanderlip.entity.TntwdEntity;
import net.mcreator.elivanderlip.entity.SpikeEntity;
import net.mcreator.elivanderlip.entity.SkbdiEntity;
import net.mcreator.elivanderlip.entity.PlaneEntity;
import net.mcreator.elivanderlip.entity.MustEntity;
import net.mcreator.elivanderlip.entity.HerobrainEntity;
import net.mcreator.elivanderlip.entity.BulletEntity;
import net.mcreator.elivanderlip.EliVanderlipMod;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD)
public class EliVanderlipModEntities {
	public static final DeferredRegister<EntityType<?>> REGISTRY = DeferredRegister.create(ForgeRegistries.ENTITY_TYPES, EliVanderlipMod.MODID);
	public static final RegistryObject<EntityType<SkbdiEntity>> SKBDI = register("skbdi",
			EntityType.Builder.<SkbdiEntity>of(SkbdiEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(3).setCustomClientFactory(SkbdiEntity::new)

					.sized(0.6f, 1.8f));
	public static final RegistryObject<EntityType<PlaneEntity>> PLANE = register("plane",
			EntityType.Builder.<PlaneEntity>of(PlaneEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(3).setCustomClientFactory(PlaneEntity::new).fireImmune().sized(0.4f, 0.7f));
	public static final RegistryObject<EntityType<MustEntity>> MUST = register("must",
			EntityType.Builder.<MustEntity>of(MustEntity::new, MobCategory.MISC).setCustomClientFactory(MustEntity::new).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(1).sized(0.5f, 0.5f));
	public static final RegistryObject<EntityType<TntwdEntity>> TNTWD = register("tntwd",
			EntityType.Builder.<TntwdEntity>of(TntwdEntity::new, MobCategory.MISC).setCustomClientFactory(TntwdEntity::new).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(1).sized(0.5f, 0.5f));
	public static final RegistryObject<EntityType<BulletEntity>> BULLET = register("bullet",
			EntityType.Builder.<BulletEntity>of(BulletEntity::new, MobCategory.MISC).setCustomClientFactory(BulletEntity::new).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(1).sized(0.5f, 0.5f));
	public static final RegistryObject<EntityType<WariorEntity>> WARIOR = register("warior",
			EntityType.Builder.<WariorEntity>of(WariorEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(3).setCustomClientFactory(WariorEntity::new).fireImmune().sized(0.4f, 0.3f));
	public static final RegistryObject<EntityType<SpikeEntity>> SPIKE = register("spike",
			EntityType.Builder.<SpikeEntity>of(SpikeEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(3).setCustomClientFactory(SpikeEntity::new).fireImmune().sized(0.6f, 1.8f));
	public static final RegistryObject<EntityType<HerobrainEntity>> HEROBRAIN = register("herobrain", EntityType.Builder.<HerobrainEntity>of(HerobrainEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true).setTrackingRange(64)
			.setUpdateInterval(3).setCustomClientFactory(HerobrainEntity::new).fireImmune().sized(0.6f, 1.8f));

	private static <T extends Entity> RegistryObject<EntityType<T>> register(String registryname, EntityType.Builder<T> entityTypeBuilder) {
		return REGISTRY.register(registryname, () -> (EntityType<T>) entityTypeBuilder.build(registryname));
	}

	@SubscribeEvent
	public static void init(FMLCommonSetupEvent event) {
		event.enqueueWork(() -> {
			SkbdiEntity.init();
			PlaneEntity.init();
			WariorEntity.init();
			SpikeEntity.init();
			HerobrainEntity.init();
		});
	}

	@SubscribeEvent
	public static void registerAttributes(EntityAttributeCreationEvent event) {
		event.put(SKBDI.get(), SkbdiEntity.createAttributes().build());
		event.put(PLANE.get(), PlaneEntity.createAttributes().build());
		event.put(WARIOR.get(), WariorEntity.createAttributes().build());
		event.put(SPIKE.get(), SpikeEntity.createAttributes().build());
		event.put(HEROBRAIN.get(), HerobrainEntity.createAttributes().build());
	}
}


/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.elivanderlip.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.item.enchantment.Enchantment;

import net.mcreator.elivanderlip.enchantment.ZapingEnchantment;
import net.mcreator.elivanderlip.EliVanderlipMod;

public class EliVanderlipModEnchantments {
	public static final DeferredRegister<Enchantment> REGISTRY = DeferredRegister.create(ForgeRegistries.ENCHANTMENTS, EliVanderlipMod.MODID);
	public static final RegistryObject<Enchantment> ZAPING = REGISTRY.register("zaping", () -> new ZapingEnchantment());
}

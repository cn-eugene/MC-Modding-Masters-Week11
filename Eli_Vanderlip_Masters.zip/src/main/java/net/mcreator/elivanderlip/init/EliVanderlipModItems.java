
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.elivanderlip.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.common.ForgeSpawnEggItem;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.BlockItem;

import net.mcreator.elivanderlip.item.Vs5hgItem;
import net.mcreator.elivanderlip.item.SusItem;
import net.mcreator.elivanderlip.item.SdcItem;
import net.mcreator.elivanderlip.item.ScytheItem;
import net.mcreator.elivanderlip.item.MusterdItem;
import net.mcreator.elivanderlip.item.McdItem;
import net.mcreator.elivanderlip.item.MasterItem;
import net.mcreator.elivanderlip.item.GunItem;
import net.mcreator.elivanderlip.item.EndmouthItem;
import net.mcreator.elivanderlip.item.ChickenItem;
import net.mcreator.elivanderlip.EliVanderlipMod;

public class EliVanderlipModItems {
	public static final DeferredRegister<Item> REGISTRY = DeferredRegister.create(ForgeRegistries.ITEMS, EliVanderlipMod.MODID);
	public static final RegistryObject<Item> SUS_HELMET = REGISTRY.register("sus_helmet", () -> new SusItem.Helmet());
	public static final RegistryObject<Item> CHICKEN = REGISTRY.register("chicken", () -> new ChickenItem());
	public static final RegistryObject<Item> SKBDI_SPAWN_EGG = REGISTRY.register("skbdi_spawn_egg", () -> new ForgeSpawnEggItem(EliVanderlipModEntities.SKBDI, -1, -1, new Item.Properties()));
	public static final RegistryObject<Item> MCD = REGISTRY.register("mcd", () -> new McdItem());
	public static final RegistryObject<Item> PLANE_SPAWN_EGG = REGISTRY.register("plane_spawn_egg", () -> new ForgeSpawnEggItem(EliVanderlipModEntities.PLANE, -1, -1, new Item.Properties()));
	public static final RegistryObject<Item> MUSTERD = REGISTRY.register("musterd", () -> new MusterdItem());
	public static final RegistryObject<Item> CHICKENN = block(EliVanderlipModBlocks.CHICKENN);
	public static final RegistryObject<Item> MASTER = REGISTRY.register("master", () -> new MasterItem());
	public static final RegistryObject<Item> SCYTHE = REGISTRY.register("scythe", () -> new ScytheItem());
	public static final RegistryObject<Item> TNT = block(EliVanderlipModBlocks.TNT);
	public static final RegistryObject<Item> ENDMOUTH = REGISTRY.register("endmouth", () -> new EndmouthItem());
	public static final RegistryObject<Item> NOTNT = block(EliVanderlipModBlocks.NOTNT);
	public static final RegistryObject<Item> VS_5HG = REGISTRY.register("vs_5hg", () -> new Vs5hgItem());
	public static final RegistryObject<Item> GUN = REGISTRY.register("gun", () -> new GunItem());
	public static final RegistryObject<Item> WARIOR_SPAWN_EGG = REGISTRY.register("warior_spawn_egg", () -> new ForgeSpawnEggItem(EliVanderlipModEntities.WARIOR, -1, -1, new Item.Properties()));
	public static final RegistryObject<Item> EYES = block(EliVanderlipModBlocks.EYES);
	public static final RegistryObject<Item> SDC = REGISTRY.register("sdc", () -> new SdcItem());
	public static final RegistryObject<Item> SPIKE_SPAWN_EGG = REGISTRY.register("spike_spawn_egg", () -> new ForgeSpawnEggItem(EliVanderlipModEntities.SPIKE, -1, -1, new Item.Properties()));
	public static final RegistryObject<Item> HEROBRAIN_SPAWN_EGG = REGISTRY.register("herobrain_spawn_egg", () -> new ForgeSpawnEggItem(EliVanderlipModEntities.HEROBRAIN, -1, -1, new Item.Properties()));

	// Start of user code block custom items
	// End of user code block custom items
	private static RegistryObject<Item> block(RegistryObject<Block> block) {
		return REGISTRY.register(block.getId().getPath(), () -> new BlockItem(block.get(), new Item.Properties()));
	}
}

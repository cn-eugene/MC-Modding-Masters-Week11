
package net.mcreator.elivanderlip.client.renderer;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;

import net.mcreator.elivanderlip.entity.SpikeEntity;
import net.mcreator.elivanderlip.client.model.ModelSpike;

public class SpikeRenderer extends MobRenderer<SpikeEntity, ModelSpike<SpikeEntity>> {
	public SpikeRenderer(EntityRendererProvider.Context context) {
		super(context, new ModelSpike(context.bakeLayer(ModelSpike.LAYER_LOCATION)), 0.5f);
	}

	@Override
	public ResourceLocation getTextureLocation(SpikeEntity entity) {
		return new ResourceLocation("eli_vanderlip:textures/entities/wd.png");
	}
}

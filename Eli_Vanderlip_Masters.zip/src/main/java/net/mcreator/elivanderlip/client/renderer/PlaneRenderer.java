
package net.mcreator.elivanderlip.client.renderer;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.model.geom.ModelLayers;
import net.minecraft.client.model.ChickenModel;

import net.mcreator.elivanderlip.entity.PlaneEntity;

public class PlaneRenderer extends MobRenderer<PlaneEntity, ChickenModel<PlaneEntity>> {
	public PlaneRenderer(EntityRendererProvider.Context context) {
		super(context, new ChickenModel(context.bakeLayer(ModelLayers.CHICKEN)), 0.5f);
	}

	@Override
	public ResourceLocation getTextureLocation(PlaneEntity entity) {
		return new ResourceLocation("eli_vanderlip:textures/entities/wd.png");
	}
}

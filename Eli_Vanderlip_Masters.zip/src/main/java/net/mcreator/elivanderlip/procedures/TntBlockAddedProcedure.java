package net.mcreator.elivanderlip.procedures;

import net.minecraft.world.entity.Entity;

public class TntBlockAddedProcedure {
	public static void execute(Entity entity, Entity sourceentity) {
		if (entity == null || sourceentity == null)
			return;
		entity.startRiding(sourceentity);
	}
}

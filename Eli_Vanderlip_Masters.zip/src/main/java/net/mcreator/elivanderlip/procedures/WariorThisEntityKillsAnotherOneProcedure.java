package net.mcreator.elivanderlip.procedures;

import net.minecraft.world.entity.Entity;

public class WariorThisEntityKillsAnotherOneProcedure {
	public static void execute(Entity entity, Entity sourceentity) {
		if (entity == null || sourceentity == null)
			return;
		entity.setNoGravity(true);
		entity.startRiding(sourceentity);
	}
}


package net.mcreator.itsemerald.item;

import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.BucketItem;

import net.mcreator.itsemerald.init.ItsemeraldModFluids;

public class HotChocolateItem extends BucketItem {
	public HotChocolateItem() {
		super(ItsemeraldModFluids.HOT_CHOCOLATE.get(), new Item.Properties().craftRemainder(Items.BUCKET).stacksTo(1).rarity(Rarity.RARE));
	}
}


package net.mcreator.itsemerald.fluid;

import net.neoforged.neoforge.fluids.BaseFlowingFluid;

import net.minecraft.world.level.material.FluidState;
import net.minecraft.world.level.material.Fluid;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.LiquidBlock;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.core.particles.ParticleOptions;

import net.mcreator.itsemerald.init.ItsemeraldModItems;
import net.mcreator.itsemerald.init.ItsemeraldModFluids;
import net.mcreator.itsemerald.init.ItsemeraldModFluidTypes;
import net.mcreator.itsemerald.init.ItsemeraldModBlocks;

public abstract class HotChocolateFluid extends BaseFlowingFluid {
	public static final BaseFlowingFluid.Properties PROPERTIES = new BaseFlowingFluid.Properties(() -> ItsemeraldModFluidTypes.HOT_CHOCOLATE_TYPE.get(), () -> ItsemeraldModFluids.HOT_CHOCOLATE.get(),
			() -> ItsemeraldModFluids.FLOWING_HOT_CHOCOLATE.get()).explosionResistance(100f).bucket(() -> ItsemeraldModItems.HOT_CHOCOLATE_BUCKET.get()).block(() -> (LiquidBlock) ItsemeraldModBlocks.HOT_CHOCOLATE.get());

	private HotChocolateFluid() {
		super(PROPERTIES);
	}

	@Override
	public ParticleOptions getDripParticle() {
		return ParticleTypes.EXPLOSION;
	}

	public static class Source extends HotChocolateFluid {
		public int getAmount(FluidState state) {
			return 8;
		}

		public boolean isSource(FluidState state) {
			return true;
		}
	}

	public static class Flowing extends HotChocolateFluid {
		protected void createFluidStateDefinition(StateDefinition.Builder<Fluid, FluidState> builder) {
			super.createFluidStateDefinition(builder);
			builder.add(LEVEL);
		}

		public int getAmount(FluidState state) {
			return state.getValue(LEVEL);
		}

		public boolean isSource(FluidState state) {
			return false;
		}
	}
}

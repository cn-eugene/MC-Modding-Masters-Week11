
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.itsemerald.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.event.BuildCreativeModeTabContentsEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;

import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.network.chat.Component;
import net.minecraft.core.registries.Registries;

import net.mcreator.itsemerald.ItsemeraldMod;

@EventBusSubscriber(bus = EventBusSubscriber.Bus.MOD)
public class ItsemeraldModTabs {
	public static final DeferredRegister<CreativeModeTab> REGISTRY = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, ItsemeraldMod.MODID);
	public static final DeferredHolder<CreativeModeTab, CreativeModeTab> MODDED_ITEMS = REGISTRY.register("modded_items",
			() -> CreativeModeTab.builder().title(Component.translatable("item_group.itsemerald.modded_items")).icon(() -> new ItemStack(ItsemeraldModItems.ULTRA_ZOMBIE_SPAWN_EGG.get())).displayItems((parameters, tabData) -> {
				tabData.accept(ItsemeraldModItems.HOT_CHOCOLATE_BUCKET.get());
				tabData.accept(ItsemeraldModItems.ULTRA_ZOMBIE_SPAWN_EGG.get());
				tabData.accept(ItsemeraldModItems.HEROBRINE_SPAWN_EGG.get());
			})

					.build());

	@SubscribeEvent
	public static void buildTabContentsVanilla(BuildCreativeModeTabContentsEvent tabData) {
		if (tabData.getTabKey() == CreativeModeTabs.SPAWN_EGGS) {
			tabData.accept(ItsemeraldModItems.ULTRA_ZOMBIE_SPAWN_EGG.get());
			tabData.accept(ItsemeraldModItems.HEROBRINE_SPAWN_EGG.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.INGREDIENTS) {
			tabData.accept(ItsemeraldModItems.HOT_CHOCOLATE_BUCKET.get());
		}
	}
}

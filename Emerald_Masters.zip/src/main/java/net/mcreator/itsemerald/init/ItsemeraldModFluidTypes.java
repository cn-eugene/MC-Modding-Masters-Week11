
/*
 * MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.itsemerald.init;

import net.neoforged.neoforge.registries.NeoForgeRegistries;
import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.fluids.FluidType;

import net.mcreator.itsemerald.fluid.types.HotChocolateFluidType;
import net.mcreator.itsemerald.ItsemeraldMod;

public class ItsemeraldModFluidTypes {
	public static final DeferredRegister<FluidType> REGISTRY = DeferredRegister.create(NeoForgeRegistries.FLUID_TYPES, ItsemeraldMod.MODID);
	public static final DeferredHolder<FluidType, FluidType> HOT_CHOCOLATE_TYPE = REGISTRY.register("hot_chocolate", () -> new HotChocolateFluidType());
}

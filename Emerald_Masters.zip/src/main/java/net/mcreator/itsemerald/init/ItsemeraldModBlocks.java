
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.itsemerald.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredHolder;

import net.minecraft.world.level.block.Block;

import net.mcreator.itsemerald.block.HotChocolateBlock;
import net.mcreator.itsemerald.ItsemeraldMod;

public class ItsemeraldModBlocks {
	public static final DeferredRegister.Blocks REGISTRY = DeferredRegister.createBlocks(ItsemeraldMod.MODID);
	public static final DeferredHolder<Block, Block> HOT_CHOCOLATE = REGISTRY.register("hot_chocolate", HotChocolateBlock::new);
	// Start of user code block custom blocks
	// End of user code block custom blocks
}

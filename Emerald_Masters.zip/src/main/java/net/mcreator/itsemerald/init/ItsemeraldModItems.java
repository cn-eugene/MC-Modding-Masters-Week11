
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.itsemerald.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.common.DeferredSpawnEggItem;

import net.minecraft.world.item.Item;

import net.mcreator.itsemerald.item.HotChocolateItem;
import net.mcreator.itsemerald.ItsemeraldMod;

public class ItsemeraldModItems {
	public static final DeferredRegister.Items REGISTRY = DeferredRegister.createItems(ItsemeraldMod.MODID);
	public static final DeferredHolder<Item, Item> HOT_CHOCOLATE_BUCKET = REGISTRY.register("hot_chocolate_bucket", HotChocolateItem::new);
	public static final DeferredHolder<Item, Item> ULTRA_ZOMBIE_SPAWN_EGG = REGISTRY.register("ultra_zombie_spawn_egg", () -> new DeferredSpawnEggItem(ItsemeraldModEntities.ULTRA_ZOMBIE, -15186426, -15531004, new Item.Properties()));
	public static final DeferredHolder<Item, Item> HEROBRINE_SPAWN_EGG = REGISTRY.register("herobrine_spawn_egg", () -> new DeferredSpawnEggItem(ItsemeraldModEntities.HEROBRINE, -1, -1, new Item.Properties()));
	// Start of user code block custom items
	// End of user code block custom items
}

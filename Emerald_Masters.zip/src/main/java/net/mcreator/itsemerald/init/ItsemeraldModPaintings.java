
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.itsemerald.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredHolder;

import net.minecraft.world.entity.decoration.PaintingVariant;
import net.minecraft.core.registries.Registries;

import net.mcreator.itsemerald.ItsemeraldMod;

public class ItsemeraldModPaintings {
	public static final DeferredRegister<PaintingVariant> REGISTRY = DeferredRegister.create(Registries.PAINTING_VARIANT, ItsemeraldMod.MODID);
	public static final DeferredHolder<PaintingVariant, PaintingVariant> EMERALDFLATS = REGISTRY.register("emeraldflats", () -> new PaintingVariant(16, 16));
}

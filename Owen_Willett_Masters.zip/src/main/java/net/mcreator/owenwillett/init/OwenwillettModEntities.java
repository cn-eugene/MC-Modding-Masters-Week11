
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.owenwillett.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.event.entity.EntityAttributeCreationEvent;

import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Entity;

import net.mcreator.owenwillett.entity.YyyEntity;
import net.mcreator.owenwillett.entity.EddieEntity;
import net.mcreator.owenwillett.OwenwillettMod;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD)
public class OwenwillettModEntities {
	public static final DeferredRegister<EntityType<?>> REGISTRY = DeferredRegister.create(ForgeRegistries.ENTITY_TYPES, OwenwillettMod.MODID);
	public static final RegistryObject<EntityType<EddieEntity>> EDDIE = register("eddie",
			EntityType.Builder.<EddieEntity>of(EddieEntity::new, MobCategory.CREATURE).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(3).setCustomClientFactory(EddieEntity::new).fireImmune().sized(0.6f, 0.7f));
	public static final RegistryObject<EntityType<YyyEntity>> YYY = register("yyy",
			EntityType.Builder.<YyyEntity>of(YyyEntity::new, MobCategory.MISC).setCustomClientFactory(YyyEntity::new).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(1).sized(0.5f, 0.5f));

	private static <T extends Entity> RegistryObject<EntityType<T>> register(String registryname, EntityType.Builder<T> entityTypeBuilder) {
		return REGISTRY.register(registryname, () -> (EntityType<T>) entityTypeBuilder.build(registryname));
	}

	@SubscribeEvent
	public static void init(FMLCommonSetupEvent event) {
		event.enqueueWork(() -> {
			EddieEntity.init();
		});
	}

	@SubscribeEvent
	public static void registerAttributes(EntityAttributeCreationEvent event) {
		event.put(EDDIE.get(), EddieEntity.createAttributes().build());
	}
}

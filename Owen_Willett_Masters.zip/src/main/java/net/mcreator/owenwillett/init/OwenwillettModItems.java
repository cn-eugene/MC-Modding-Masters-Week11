
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.owenwillett.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.common.ForgeSpawnEggItem;

import net.minecraft.world.item.Item;

import net.mcreator.owenwillett.item.EddiepopsicleItem;
import net.mcreator.owenwillett.item.DurpyswordItem;
import net.mcreator.owenwillett.OwenwillettMod;

public class OwenwillettModItems {
	public static final DeferredRegister<Item> REGISTRY = DeferredRegister.create(ForgeRegistries.ITEMS, OwenwillettMod.MODID);
	public static final RegistryObject<Item> EDDIEPOPSICLE = REGISTRY.register("eddiepopsicle", () -> new EddiepopsicleItem());
	public static final RegistryObject<Item> EDDIE_SPAWN_EGG = REGISTRY.register("eddie_spawn_egg", () -> new ForgeSpawnEggItem(OwenwillettModEntities.EDDIE, -16777216, -16764109, new Item.Properties()));
	public static final RegistryObject<Item> DURPYSWORD = REGISTRY.register("durpysword", () -> new DurpyswordItem());
	// Start of user code block custom items
	// End of user code block custom items
}

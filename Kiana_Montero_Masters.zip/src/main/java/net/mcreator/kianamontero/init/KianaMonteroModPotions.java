
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.kianamontero.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.item.alchemy.Potion;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.effect.MobEffectInstance;

import net.mcreator.kianamontero.KianaMonteroMod;

public class KianaMonteroModPotions {
	public static final DeferredRegister<Potion> REGISTRY = DeferredRegister.create(ForgeRegistries.POTIONS, KianaMonteroMod.MODID);
	public static final RegistryObject<Potion> AXOLOTL_POTION = REGISTRY.register("axolotl_potion",
			() -> new Potion(new MobEffectInstance(MobEffects.WATER_BREATHING, 3600, 0, false, true), new MobEffectInstance(MobEffects.NIGHT_VISION, 3600, 0, false, true), new MobEffectInstance(MobEffects.REGENERATION, 3600, 0, false, true),
					new MobEffectInstance(MobEffects.DOLPHINS_GRACE, 3600, 0, false, true), new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 3600, 0, false, true)));
	public static final RegistryObject<Potion> AXOLOTL_RAIN = REGISTRY.register("axolotl_rain", () -> new Potion(new MobEffectInstance(KianaMonteroModMobEffects.AXOLOTL_RAINING_POTION.get(), 600, 0, false, false)));
}

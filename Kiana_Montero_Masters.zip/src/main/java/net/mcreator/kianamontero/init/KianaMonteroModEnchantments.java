
/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.kianamontero.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.item.enchantment.Enchantment;

import net.mcreator.kianamontero.enchantment.AxolotlShieldEnchantment;
import net.mcreator.kianamontero.KianaMonteroMod;

public class KianaMonteroModEnchantments {
	public static final DeferredRegister<Enchantment> REGISTRY = DeferredRegister.create(ForgeRegistries.ENCHANTMENTS, KianaMonteroMod.MODID);
	public static final RegistryObject<Enchantment> AXOLOTL_SHIELD = REGISTRY.register("axolotl_shield", () -> new AxolotlShieldEnchantment());
}

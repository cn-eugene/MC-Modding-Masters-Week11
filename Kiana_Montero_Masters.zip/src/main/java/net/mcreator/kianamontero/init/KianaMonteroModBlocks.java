
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.kianamontero.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.level.block.Block;

import net.mcreator.kianamontero.block.AxolotlTNTBlockBlock;
import net.mcreator.kianamontero.block.AxolotlOreBlockBlock;
import net.mcreator.kianamontero.block.AxolotlBlockBlock;
import net.mcreator.kianamontero.KianaMonteroMod;

public class KianaMonteroModBlocks {
	public static final DeferredRegister<Block> REGISTRY = DeferredRegister.create(ForgeRegistries.BLOCKS, KianaMonteroMod.MODID);
	public static final RegistryObject<Block> AXOLOTL_ORE_BLOCK = REGISTRY.register("axolotl_ore_block", () -> new AxolotlOreBlockBlock());
	public static final RegistryObject<Block> AXOLOTL_BLOCK = REGISTRY.register("axolotl_block", () -> new AxolotlBlockBlock());
	public static final RegistryObject<Block> AXOLOTL_TNT_BLOCK = REGISTRY.register("axolotl_tnt_block", () -> new AxolotlTNTBlockBlock());
	// Start of user code block custom blocks
	// End of user code block custom blocks
}

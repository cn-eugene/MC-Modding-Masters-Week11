
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.kianamontero.init;

import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.event.BuildCreativeModeTabContentsEvent;

import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.core.registries.Registries;

import net.mcreator.kianamontero.KianaMonteroMod;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD)
public class KianaMonteroModTabs {
	public static final DeferredRegister<CreativeModeTab> REGISTRY = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, KianaMonteroMod.MODID);

	@SubscribeEvent
	public static void buildTabContentsVanilla(BuildCreativeModeTabContentsEvent tabData) {
		if (tabData.getTabKey() == CreativeModeTabs.BUILDING_BLOCKS) {
			tabData.accept(KianaMonteroModBlocks.AXOLOTL_BLOCK.get().asItem());
		} else if (tabData.getTabKey() == CreativeModeTabs.REDSTONE_BLOCKS) {
			tabData.accept(KianaMonteroModBlocks.AXOLOTL_TNT_BLOCK.get().asItem());
		} else if (tabData.getTabKey() == CreativeModeTabs.COMBAT) {
			tabData.accept(KianaMonteroModItems.AXOLOTL_WEAPON.get());
			tabData.accept(KianaMonteroModItems.AXOLOTL_ARMOR_HELMET.get());
			tabData.accept(KianaMonteroModItems.AXOLOTL_ARMOR_CHESTPLATE.get());
			tabData.accept(KianaMonteroModItems.AXOLOTL_ARMOR_LEGGINGS.get());
			tabData.accept(KianaMonteroModItems.AXOLOTL_ARMOR_BOOTS.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.INGREDIENTS) {
			tabData.accept(KianaMonteroModItems.AXOLOTL_ORE.get());
			tabData.accept(KianaMonteroModItems.AXOLOTL_INGOT.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.NATURAL_BLOCKS) {
			tabData.accept(KianaMonteroModBlocks.AXOLOTL_ORE_BLOCK.get().asItem());
		}
	}
}

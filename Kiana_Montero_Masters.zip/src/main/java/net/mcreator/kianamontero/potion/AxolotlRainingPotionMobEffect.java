
package net.mcreator.kianamontero.potion;

import net.minecraft.world.entity.ai.attributes.AttributeMap;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.effect.MobEffectCategory;
import net.minecraft.world.effect.MobEffect;

import net.mcreator.kianamontero.procedures.PotionProcedure1Procedure;
import net.mcreator.kianamontero.procedures.AxolotlRainingPotionEffectExpiresProcedure;

public class AxolotlRainingPotionMobEffect extends MobEffect {
	public AxolotlRainingPotionMobEffect() {
		super(MobEffectCategory.NEUTRAL, -31355);
	}

	@Override
	public void addAttributeModifiers(LivingEntity entity, AttributeMap attributeMap, int amplifier) {
		PotionProcedure1Procedure.execute(entity.level(), entity);
	}

	@Override
	public void removeAttributeModifiers(LivingEntity entity, AttributeMap attributeMap, int amplifier) {
		super.removeAttributeModifiers(entity, attributeMap, amplifier);
		AxolotlRainingPotionEffectExpiresProcedure.execute(entity.level(), entity.getX(), entity.getY(), entity.getZ());
	}

	@Override
	public boolean isDurationEffectTick(int duration, int amplifier) {
		return true;
	}
}

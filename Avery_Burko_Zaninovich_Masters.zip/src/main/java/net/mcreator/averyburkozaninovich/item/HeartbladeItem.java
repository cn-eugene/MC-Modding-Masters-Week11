
package net.mcreator.averyburkozaninovich.item;

import net.minecraftforge.api.distmarker.OnlyIn;
import net.minecraftforge.api.distmarker.Dist;

import net.minecraft.world.level.Level;
import net.minecraft.world.item.crafting.Ingredient;
import net.minecraft.world.item.Tier;
import net.minecraft.world.item.SwordItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Item;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Entity;

import net.mcreator.averyburkozaninovich.procedures.HeartbladeToolInInventoryTickProcedure;

public class HeartbladeItem extends SwordItem {
	public HeartbladeItem() {
		super(new Tier() {
			public int getUses() {
				return 1100;
			}

			public float getSpeed() {
				return 46f;
			}

			public float getAttackDamageBonus() {
				return 99995f;
			}

			public int getLevel() {
				return 0;
			}

			public int getEnchantmentValue() {
				return 255;
			}

			public Ingredient getRepairIngredient() {
				return Ingredient.of();
			}
		}, 3, 95f, new Item.Properties().fireResistant());
	}

	@Override
	public boolean hurtEnemy(ItemStack itemstack, LivingEntity entity, LivingEntity sourceentity) {
		boolean retval = super.hurtEnemy(itemstack, entity, sourceentity);
		HeartbladeToolInInventoryTickProcedure.execute();
		return retval;
	}

	@Override
	public boolean hasCraftingRemainingItem(ItemStack stack) {
		return true;
	}

	@Override
	public ItemStack getCraftingRemainingItem(ItemStack itemstack) {
		return new ItemStack(this);
	}

	@Override
	public boolean isRepairable(ItemStack itemstack) {
		return false;
	}

	@Override
	public void inventoryTick(ItemStack itemstack, Level world, Entity entity, int slot, boolean selected) {
		super.inventoryTick(itemstack, world, entity, slot, selected);
		HeartbladeToolInInventoryTickProcedure.execute();
	}

	@Override
	@OnlyIn(Dist.CLIENT)
	public boolean isFoil(ItemStack itemstack) {
		return true;
	}
}

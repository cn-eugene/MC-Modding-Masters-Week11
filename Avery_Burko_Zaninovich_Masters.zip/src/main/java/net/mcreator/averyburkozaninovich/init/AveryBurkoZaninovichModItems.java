
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.averyburkozaninovich.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.BlockItem;

import net.mcreator.averyburkozaninovich.item.TurtleItem;
import net.mcreator.averyburkozaninovich.item.TestItem;
import net.mcreator.averyburkozaninovich.item.KNIFEItem;
import net.mcreator.averyburkozaninovich.item.HeartbladeItem;
import net.mcreator.averyburkozaninovich.item.HeartItem;
import net.mcreator.averyburkozaninovich.item.GunItem;
import net.mcreator.averyburkozaninovich.AveryBurkoZaninovichMod;

public class AveryBurkoZaninovichModItems {
	public static final DeferredRegister<Item> REGISTRY = DeferredRegister.create(ForgeRegistries.ITEMS, AveryBurkoZaninovichMod.MODID);
	public static final RegistryObject<Item> NAPSTABOOKITE = block(AveryBurkoZaninovichModBlocks.NAPSTABOOKITE);
	public static final RegistryObject<Item> HEART = REGISTRY.register("heart", () -> new HeartItem());
	public static final RegistryObject<Item> HEARTBLOCK = block(AveryBurkoZaninovichModBlocks.HEARTBLOCK);
	public static final RegistryObject<Item> HEARTBLADE = REGISTRY.register("heartblade", () -> new HeartbladeItem());
	public static final RegistryObject<Item> TEST = REGISTRY.register("test", () -> new TestItem());
	public static final RegistryObject<Item> GUN = REGISTRY.register("gun", () -> new GunItem());
	public static final RegistryObject<Item> NUKE = block(AveryBurkoZaninovichModBlocks.NUKE);
	public static final RegistryObject<Item> KNIFE = REGISTRY.register("knife", () -> new KNIFEItem());
	public static final RegistryObject<Item> TURTLE = REGISTRY.register("turtle", () -> new TurtleItem());

	// Start of user code block custom items
	// End of user code block custom items
	private static RegistryObject<Item> block(RegistryObject<Block> block) {
		return REGISTRY.register(block.getId().getPath(), () -> new BlockItem(block.get(), new Item.Properties()));
	}
}

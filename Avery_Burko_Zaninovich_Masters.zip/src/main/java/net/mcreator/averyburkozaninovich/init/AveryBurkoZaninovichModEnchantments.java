
/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.averyburkozaninovich.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.item.enchantment.Enchantment;

import net.mcreator.averyburkozaninovich.enchantment.BloodshedEnchantment;
import net.mcreator.averyburkozaninovich.AveryBurkoZaninovichMod;

public class AveryBurkoZaninovichModEnchantments {
	public static final DeferredRegister<Enchantment> REGISTRY = DeferredRegister.create(ForgeRegistries.ENCHANTMENTS, AveryBurkoZaninovichMod.MODID);
	public static final RegistryObject<Enchantment> BLOODSHED = REGISTRY.register("bloodshed", () -> new BloodshedEnchantment());
}


/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.averyburkozaninovich.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.level.block.Block;

import net.mcreator.averyburkozaninovich.block.NukeBlock;
import net.mcreator.averyburkozaninovich.block.NapstabookiteBlock;
import net.mcreator.averyburkozaninovich.block.HeartblockBlock;
import net.mcreator.averyburkozaninovich.AveryBurkoZaninovichMod;

public class AveryBurkoZaninovichModBlocks {
	public static final DeferredRegister<Block> REGISTRY = DeferredRegister.create(ForgeRegistries.BLOCKS, AveryBurkoZaninovichMod.MODID);
	public static final RegistryObject<Block> NAPSTABOOKITE = REGISTRY.register("napstabookite", () -> new NapstabookiteBlock());
	public static final RegistryObject<Block> HEARTBLOCK = REGISTRY.register("heartblock", () -> new HeartblockBlock());
	public static final RegistryObject<Block> NUKE = REGISTRY.register("nuke", () -> new NukeBlock());
	// Start of user code block custom blocks
	// End of user code block custom blocks
}

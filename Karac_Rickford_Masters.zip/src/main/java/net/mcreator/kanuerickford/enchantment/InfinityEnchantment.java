
package net.mcreator.kanuerickford.enchantment;

import net.minecraft.world.item.enchantment.EnchantmentCategory;
import net.minecraft.world.item.enchantment.Enchantment;
import net.minecraft.world.item.crafting.Ingredient;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.entity.EquipmentSlot;

import net.mcreator.kanuerickford.init.KanueRickfordModItems;

public class InfinityEnchantment extends Enchantment {
	public InfinityEnchantment(EquipmentSlot... slots) {
		super(Enchantment.Rarity.COMMON, EnchantmentCategory.BREAKABLE, slots);
	}

	@Override
	public boolean canApplyAtEnchantingTable(ItemStack itemstack) {
		return Ingredient.of(new ItemStack(KanueRickfordModItems.GRENADE.get())).test(itemstack);
	}

	@Override
	public boolean isTradeable() {
		return false;
	}
}

package net.mcreator.kanuerickford.procedures;

public class IronmanarmorLeggingsTickEventProcedure {
	public static void execute() {
	}
}

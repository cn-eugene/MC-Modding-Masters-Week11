package net.mcreator.kanuerickford.procedures;

public class TrickgrenadeProcedure {
	public static void execute() {
	}
}

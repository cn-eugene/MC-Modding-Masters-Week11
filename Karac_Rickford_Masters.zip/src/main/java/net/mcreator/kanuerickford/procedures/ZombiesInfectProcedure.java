package net.mcreator.kanuerickford.procedures;

import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.eventbus.api.Event;
import net.minecraftforge.event.entity.living.LivingAttackEvent;

import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.util.RandomSource;
import net.minecraft.util.Mth;

import net.mcreator.kanuerickford.init.KanueRickfordModMobEffects;

import javax.annotation.Nullable;

@Mod.EventBusSubscriber
public class ZombiesInfectProcedure {
	@SubscribeEvent
	public static void onEntityAttacked(LivingAttackEvent event) {
		if (event != null && event.getEntity() != null) {
			execute(event, event.getEntity(), event.getSource().getEntity());
		}
	}

	public static void execute(Entity entity, Entity sourceentity) {
		execute(null, entity, sourceentity);
	}

	private static void execute(@Nullable Event event, Entity entity, Entity sourceentity) {
		if (entity == null || sourceentity == null)
			return;
		if (("minecraft:drowned").equals(ForgeRegistries.ENTITY_TYPES.getKey(sourceentity.getType()).toString()) || ("minecraft:husk").equals(ForgeRegistries.ENTITY_TYPES.getKey(sourceentity.getType()).toString())
				|| ("minecraft:zombie").equals(ForgeRegistries.ENTITY_TYPES.getKey(sourceentity.getType()).toString())) {
			if (Mth.nextInt(RandomSource.create(), 1, 20) == 1) {
				if (entity instanceof LivingEntity _entity && !_entity.level().isClientSide())
					_entity.addEffect(new MobEffectInstance(KanueRickfordModMobEffects.ZOMBIFED.get(), 60, 1));
			}
		}
	}
}

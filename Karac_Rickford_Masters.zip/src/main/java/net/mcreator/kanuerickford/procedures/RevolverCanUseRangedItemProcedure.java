package net.mcreator.kanuerickford.procedures;

import net.minecraft.world.item.ItemStack;

public class RevolverCanUseRangedItemProcedure {
	public static boolean execute(ItemStack itemstack) {
		if (8 > itemstack.getDamageValue()) {
			return true;
		}
		return false;
	}
}

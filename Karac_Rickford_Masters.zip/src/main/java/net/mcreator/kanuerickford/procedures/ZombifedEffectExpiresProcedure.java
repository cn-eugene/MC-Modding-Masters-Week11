package net.mcreator.kanuerickford.procedures;

import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.effect.MobEffectInstance;

import net.mcreator.kanuerickford.init.KanueRickfordModMobEffects;

public class ZombifedEffectExpiresProcedure {
	public static void execute(Entity entity) {
		if (entity == null)
			return;
		if (!(1 <= (entity instanceof LivingEntity _livEnt && _livEnt.hasEffect(KanueRickfordModMobEffects.CURE.get()) ? _livEnt.getEffect(KanueRickfordModMobEffects.CURE.get()).getDuration() : 0))) {
			if (entity instanceof LivingEntity _entity && !_entity.level().isClientSide())
				_entity.addEffect(new MobEffectInstance(KanueRickfordModMobEffects.ZOMBIFED.get(), 1200, 0));
		}
	}
}

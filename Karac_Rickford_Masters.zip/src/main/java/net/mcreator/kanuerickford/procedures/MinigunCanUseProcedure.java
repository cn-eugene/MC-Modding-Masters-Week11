package net.mcreator.kanuerickford.procedures;

import net.minecraft.world.item.ItemStack;

public class MinigunCanUseProcedure {
	public static boolean execute(ItemStack itemstack) {
		if (200 > itemstack.getDamageValue()) {
			return true;
		}
		return false;
	}
}

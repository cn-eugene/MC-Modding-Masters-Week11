
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.kanuerickford.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.level.block.Block;

import net.mcreator.kanuerickford.block.SlipperyBlock;
import net.mcreator.kanuerickford.block.RubyoreBlock;
import net.mcreator.kanuerickford.block.LandmineBlock;
import net.mcreator.kanuerickford.block.GunTableBlock;
import net.mcreator.kanuerickford.KanueRickfordMod;

public class KanueRickfordModBlocks {
	public static final DeferredRegister<Block> REGISTRY = DeferredRegister.create(ForgeRegistries.BLOCKS, KanueRickfordMod.MODID);
	public static final RegistryObject<Block> RUBYORE = REGISTRY.register("rubyore", () -> new RubyoreBlock());
	public static final RegistryObject<Block> SLIPPERY = REGISTRY.register("slippery", () -> new SlipperyBlock());
	public static final RegistryObject<Block> LANDMINE = REGISTRY.register("landmine", () -> new LandmineBlock());
	public static final RegistryObject<Block> GUN_TABLE = REGISTRY.register("gun_table", () -> new GunTableBlock());
	// Start of user code block custom blocks
	// End of user code block custom blocks
}

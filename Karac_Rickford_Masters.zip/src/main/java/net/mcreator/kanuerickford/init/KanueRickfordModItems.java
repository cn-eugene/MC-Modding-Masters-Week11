
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.kanuerickford.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.BlockItem;

import net.mcreator.kanuerickford.item.TaserItem;
import net.mcreator.kanuerickford.item.RubyItem;
import net.mcreator.kanuerickford.item.RevolverItem;
import net.mcreator.kanuerickford.item.MinygunItem;
import net.mcreator.kanuerickford.item.LazerItemItem;
import net.mcreator.kanuerickford.item.IronmanarmorItem;
import net.mcreator.kanuerickford.item.HoneysandwichItem;
import net.mcreator.kanuerickford.item.GrenadeItem;
import net.mcreator.kanuerickford.item.BulletitemItem;
import net.mcreator.kanuerickford.item.ArcreactorItem;
import net.mcreator.kanuerickford.KanueRickfordMod;

public class KanueRickfordModItems {
	public static final DeferredRegister<Item> REGISTRY = DeferredRegister.create(ForgeRegistries.ITEMS, KanueRickfordMod.MODID);
	public static final RegistryObject<Item> RUBY = REGISTRY.register("ruby", () -> new RubyItem());
	public static final RegistryObject<Item> RUBYORE = block(KanueRickfordModBlocks.RUBYORE);
	public static final RegistryObject<Item> SLIPPERY = block(KanueRickfordModBlocks.SLIPPERY);
	public static final RegistryObject<Item> HONEYSANDWICH = REGISTRY.register("honeysandwich", () -> new HoneysandwichItem());
	public static final RegistryObject<Item> TASER = REGISTRY.register("taser", () -> new TaserItem());
	public static final RegistryObject<Item> GRENADE = REGISTRY.register("grenade", () -> new GrenadeItem());
	public static final RegistryObject<Item> LANDMINE = block(KanueRickfordModBlocks.LANDMINE);
	public static final RegistryObject<Item> GUN_TABLE = block(KanueRickfordModBlocks.GUN_TABLE);
	public static final RegistryObject<Item> REVOLVER = REGISTRY.register("revolver", () -> new RevolverItem());
	public static final RegistryObject<Item> BULLETITEM = REGISTRY.register("bulletitem", () -> new BulletitemItem());
	public static final RegistryObject<Item> MINYGUN = REGISTRY.register("minygun", () -> new MinygunItem());
	public static final RegistryObject<Item> IRONMANARMOR_HELMET = REGISTRY.register("ironmanarmor_helmet", () -> new IronmanarmorItem.Helmet());
	public static final RegistryObject<Item> IRONMANARMOR_CHESTPLATE = REGISTRY.register("ironmanarmor_chestplate", () -> new IronmanarmorItem.Chestplate());
	public static final RegistryObject<Item> IRONMANARMOR_LEGGINGS = REGISTRY.register("ironmanarmor_leggings", () -> new IronmanarmorItem.Leggings());
	public static final RegistryObject<Item> IRONMANARMOR_BOOTS = REGISTRY.register("ironmanarmor_boots", () -> new IronmanarmorItem.Boots());
	public static final RegistryObject<Item> ARCREACTOR = REGISTRY.register("arcreactor", () -> new ArcreactorItem());
	public static final RegistryObject<Item> LAZER_ITEM = REGISTRY.register("lazer_item", () -> new LazerItemItem());

	// Start of user code block custom items
	// End of user code block custom items
	private static RegistryObject<Item> block(RegistryObject<Block> block) {
		return REGISTRY.register(block.getId().getPath(), () -> new BlockItem(block.get(), new Item.Properties()));
	}
}

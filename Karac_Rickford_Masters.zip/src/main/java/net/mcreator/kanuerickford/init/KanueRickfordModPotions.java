
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.kanuerickford.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.item.alchemy.Potion;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.effect.MobEffectInstance;

import net.mcreator.kanuerickford.KanueRickfordMod;

public class KanueRickfordModPotions {
	public static final DeferredRegister<Potion> REGISTRY = DeferredRegister.create(ForgeRegistries.POTIONS, KanueRickfordMod.MODID);
	public static final RegistryObject<Potion> CURE_POTION = REGISTRY.register("cure_potion", () -> new Potion(new MobEffectInstance(KanueRickfordModMobEffects.CURE.get(), 20, 0, false, true)));
	public static final RegistryObject<Potion> CURE_STEP_1 = REGISTRY.register("cure_step_1", () -> new Potion(new MobEffectInstance(MobEffects.ABSORPTION, 20, 0, false, true)));
}

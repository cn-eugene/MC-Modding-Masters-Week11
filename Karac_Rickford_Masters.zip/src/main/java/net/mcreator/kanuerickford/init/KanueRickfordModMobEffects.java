
/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.kanuerickford.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.effect.MobEffect;

import net.mcreator.kanuerickford.potion.ZombifedMobEffect;
import net.mcreator.kanuerickford.potion.StunnedMobEffect;
import net.mcreator.kanuerickford.potion.CureMobEffect;
import net.mcreator.kanuerickford.KanueRickfordMod;

public class KanueRickfordModMobEffects {
	public static final DeferredRegister<MobEffect> REGISTRY = DeferredRegister.create(ForgeRegistries.MOB_EFFECTS, KanueRickfordMod.MODID);
	public static final RegistryObject<MobEffect> STUNNED = REGISTRY.register("stunned", () -> new StunnedMobEffect());
	public static final RegistryObject<MobEffect> CURE = REGISTRY.register("cure", () -> new CureMobEffect());
	public static final RegistryObject<MobEffect> ZOMBIFED = REGISTRY.register("zombifed", () -> new ZombifedMobEffect());
}

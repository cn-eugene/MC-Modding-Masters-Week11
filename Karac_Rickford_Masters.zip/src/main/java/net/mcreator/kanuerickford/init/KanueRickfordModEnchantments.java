
/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.kanuerickford.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.item.enchantment.Enchantment;

import net.mcreator.kanuerickford.enchantment.InfinityEnchantment;
import net.mcreator.kanuerickford.KanueRickfordMod;

public class KanueRickfordModEnchantments {
	public static final DeferredRegister<Enchantment> REGISTRY = DeferredRegister.create(ForgeRegistries.ENCHANTMENTS, KanueRickfordMod.MODID);
	public static final RegistryObject<Enchantment> INFINITY = REGISTRY.register("infinity", () -> new InfinityEnchantment());
}

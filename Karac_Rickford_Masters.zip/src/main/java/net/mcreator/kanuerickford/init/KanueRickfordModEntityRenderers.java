
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.kanuerickford.init;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.api.distmarker.Dist;

import net.minecraft.client.renderer.entity.ThrownItemRenderer;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public class KanueRickfordModEntityRenderers {
	@SubscribeEvent
	public static void registerEntityRenderers(EntityRenderersEvent.RegisterRenderers event) {
		event.registerEntityRenderer(KanueRickfordModEntities.GRENADEPROJECTILE.get(), ThrownItemRenderer::new);
		event.registerEntityRenderer(KanueRickfordModEntities.NOTHING.get(), ThrownItemRenderer::new);
		event.registerEntityRenderer(KanueRickfordModEntities.BULLET.get(), ThrownItemRenderer::new);
		event.registerEntityRenderer(KanueRickfordModEntities.LASER.get(), ThrownItemRenderer::new);
	}
}


package net.mcreator.kanuerickford.potion;

import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.effect.MobEffectCategory;
import net.minecraft.world.effect.MobEffect;

import net.mcreator.kanuerickford.procedures.CureOnEffectActiveTickProcedure;

public class CureMobEffect extends MobEffect {
	public CureMobEffect() {
		super(MobEffectCategory.NEUTRAL, -16711936);
	}

	@Override
	public void applyEffectTick(LivingEntity entity, int amplifier) {
		CureOnEffectActiveTickProcedure.execute(entity);
	}

	@Override
	public boolean isDurationEffectTick(int duration, int amplifier) {
		return true;
	}
}

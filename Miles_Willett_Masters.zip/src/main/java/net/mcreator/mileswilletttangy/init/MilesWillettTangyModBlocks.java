
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.mileswilletttangy.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.level.block.Block;

import net.mcreator.mileswilletttangy.block.TigerseyetangyBlock;
import net.mcreator.mileswilletttangy.block.TangyPortalBlock;
import net.mcreator.mileswilletttangy.block.NucleardinamiteBlock;
import net.mcreator.mileswilletttangy.MilesWillettTangyMod;

public class MilesWillettTangyModBlocks {
	public static final DeferredRegister<Block> REGISTRY = DeferredRegister.create(ForgeRegistries.BLOCKS, MilesWillettTangyMod.MODID);
	public static final RegistryObject<Block> TIGERSEYETANGY = REGISTRY.register("tigerseyetangy", () -> new TigerseyetangyBlock());
	public static final RegistryObject<Block> NUCLEARDINAMITE = REGISTRY.register("nucleardinamite", () -> new NucleardinamiteBlock());
	public static final RegistryObject<Block> TANGY_PORTAL = REGISTRY.register("tangy_portal", () -> new TangyPortalBlock());
	// Start of user code block custom blocks
	// End of user code block custom blocks
}

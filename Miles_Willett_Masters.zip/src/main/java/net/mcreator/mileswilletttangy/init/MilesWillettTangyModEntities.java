
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.mileswilletttangy.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.event.entity.EntityAttributeCreationEvent;

import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Entity;

import net.mcreator.mileswilletttangy.entity.TunaEntityProjectile;
import net.mcreator.mileswilletttangy.entity.TunaEntity;
import net.mcreator.mileswilletttangy.entity.TangyhelperEntity;
import net.mcreator.mileswilletttangy.entity.BeardeddragonEntity;
import net.mcreator.mileswilletttangy.MilesWillettTangyMod;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD)
public class MilesWillettTangyModEntities {
	public static final DeferredRegister<EntityType<?>> REGISTRY = DeferredRegister.create(ForgeRegistries.ENTITY_TYPES, MilesWillettTangyMod.MODID);
	public static final RegistryObject<EntityType<BeardeddragonEntity>> BEARDEDDRAGON = register("beardeddragon",
			EntityType.Builder.<BeardeddragonEntity>of(BeardeddragonEntity::new, MobCategory.CREATURE).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(3).setCustomClientFactory(BeardeddragonEntity::new)

					.sized(0.6f, 0.7f));
	public static final RegistryObject<EntityType<TangyhelperEntity>> TANGYHELPER = register("tangyhelper",
			EntityType.Builder.<TangyhelperEntity>of(TangyhelperEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(3).setCustomClientFactory(TangyhelperEntity::new)

					.sized(0.6f, 0.7f));
	public static final RegistryObject<EntityType<TunaEntity>> TUNA = register("tuna",
			EntityType.Builder.<TunaEntity>of(TunaEntity::new, MobCategory.CREATURE).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(3).setCustomClientFactory(TunaEntity::new)

					.sized(0.6f, 0.7f));
	public static final RegistryObject<EntityType<TunaEntityProjectile>> TUNA_PROJECTILE = register("projectile_tuna",
			EntityType.Builder.<TunaEntityProjectile>of(TunaEntityProjectile::new, MobCategory.MISC).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(1).setCustomClientFactory(TunaEntityProjectile::new).sized(0.5f, 0.5f));

	private static <T extends Entity> RegistryObject<EntityType<T>> register(String registryname, EntityType.Builder<T> entityTypeBuilder) {
		return REGISTRY.register(registryname, () -> (EntityType<T>) entityTypeBuilder.build(registryname));
	}

	@SubscribeEvent
	public static void init(FMLCommonSetupEvent event) {
		event.enqueueWork(() -> {
			BeardeddragonEntity.init();
			TangyhelperEntity.init();
			TunaEntity.init();
		});
	}

	@SubscribeEvent
	public static void registerAttributes(EntityAttributeCreationEvent event) {
		event.put(BEARDEDDRAGON.get(), BeardeddragonEntity.createAttributes().build());
		event.put(TANGYHELPER.get(), TangyhelperEntity.createAttributes().build());
		event.put(TUNA.get(), TunaEntity.createAttributes().build());
	}
}

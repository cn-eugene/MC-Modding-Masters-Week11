
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.mileswilletttangy.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.common.ForgeSpawnEggItem;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.BlockItem;

import net.mcreator.mileswilletttangy.item.TigerseyeItem;
import net.mcreator.mileswilletttangy.item.TangyItem;
import net.mcreator.mileswilletttangy.item.SwordofthetigerItem;
import net.mcreator.mileswilletttangy.MilesWillettTangyMod;

public class MilesWillettTangyModItems {
	public static final DeferredRegister<Item> REGISTRY = DeferredRegister.create(ForgeRegistries.ITEMS, MilesWillettTangyMod.MODID);
	public static final RegistryObject<Item> TIGERSEYE = REGISTRY.register("tigerseye", () -> new TigerseyeItem());
	public static final RegistryObject<Item> TIGERSEYETANGY = block(MilesWillettTangyModBlocks.TIGERSEYETANGY);
	public static final RegistryObject<Item> SWORDOFTHETIGER = REGISTRY.register("swordofthetiger", () -> new SwordofthetigerItem());
	public static final RegistryObject<Item> NUCLEARDINAMITE = block(MilesWillettTangyModBlocks.NUCLEARDINAMITE);
	public static final RegistryObject<Item> TANGY = REGISTRY.register("tangy", () -> new TangyItem());
	public static final RegistryObject<Item> BEARDEDDRAGON_SPAWN_EGG = REGISTRY.register("beardeddragon_spawn_egg", () -> new ForgeSpawnEggItem(MilesWillettTangyModEntities.BEARDEDDRAGON, -1, -1, new Item.Properties()));
	public static final RegistryObject<Item> TANGYHELPER_SPAWN_EGG = REGISTRY.register("tangyhelper_spawn_egg", () -> new ForgeSpawnEggItem(MilesWillettTangyModEntities.TANGYHELPER, -1, -1, new Item.Properties()));
	public static final RegistryObject<Item> TUNA_SPAWN_EGG = REGISTRY.register("tuna_spawn_egg", () -> new ForgeSpawnEggItem(MilesWillettTangyModEntities.TUNA, -1, -1, new Item.Properties()));

	// Start of user code block custom items
	// End of user code block custom items
	private static RegistryObject<Item> block(RegistryObject<Block> block) {
		return REGISTRY.register(block.getId().getPath(), () -> new BlockItem(block.get(), new Item.Properties()));
	}
}


/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.mileswilletttangy.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.item.alchemy.Potion;
import net.minecraft.world.effect.MobEffectInstance;

import net.mcreator.mileswilletttangy.MilesWillettTangyMod;

public class MilesWillettTangyModPotions {
	public static final DeferredRegister<Potion> REGISTRY = DeferredRegister.create(ForgeRegistries.POTIONS, MilesWillettTangyMod.MODID);
	public static final RegistryObject<Potion> FIRERAIN = REGISTRY.register("firerain", () -> new Potion(new MobEffectInstance(MilesWillettTangyModMobEffects.FIREEEEEEEEEEEA.get(), 3600, 0, false, true)));
}

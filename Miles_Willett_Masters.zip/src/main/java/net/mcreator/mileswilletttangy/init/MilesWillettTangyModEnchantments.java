
/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.mileswilletttangy.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.item.enchantment.Enchantment;

import net.mcreator.mileswilletttangy.enchantment.TangyenchantmentEnchantment;
import net.mcreator.mileswilletttangy.MilesWillettTangyMod;

public class MilesWillettTangyModEnchantments {
	public static final DeferredRegister<Enchantment> REGISTRY = DeferredRegister.create(ForgeRegistries.ENCHANTMENTS, MilesWillettTangyMod.MODID);
	public static final RegistryObject<Enchantment> TANGYENCHANTMENT = REGISTRY.register("tangyenchantment", () -> new TangyenchantmentEnchantment());
}

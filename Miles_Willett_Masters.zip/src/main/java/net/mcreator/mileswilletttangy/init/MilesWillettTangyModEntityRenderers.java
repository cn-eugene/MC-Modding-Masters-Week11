
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.mileswilletttangy.init;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.api.distmarker.Dist;

import net.minecraft.client.renderer.entity.ThrownItemRenderer;

import net.mcreator.mileswilletttangy.client.renderer.TunaRenderer;
import net.mcreator.mileswilletttangy.client.renderer.TangyhelperRenderer;
import net.mcreator.mileswilletttangy.client.renderer.BeardeddragonRenderer;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public class MilesWillettTangyModEntityRenderers {
	@SubscribeEvent
	public static void registerEntityRenderers(EntityRenderersEvent.RegisterRenderers event) {
		event.registerEntityRenderer(MilesWillettTangyModEntities.BEARDEDDRAGON.get(), BeardeddragonRenderer::new);
		event.registerEntityRenderer(MilesWillettTangyModEntities.TANGYHELPER.get(), TangyhelperRenderer::new);
		event.registerEntityRenderer(MilesWillettTangyModEntities.TUNA.get(), TunaRenderer::new);
		event.registerEntityRenderer(MilesWillettTangyModEntities.TUNA_PROJECTILE.get(), ThrownItemRenderer::new);
	}
}


package net.mcreator.mileswilletttangy.enchantment;

import net.minecraft.world.item.enchantment.Enchantments;
import net.minecraft.world.item.enchantment.EnchantmentCategory;
import net.minecraft.world.item.enchantment.Enchantment;
import net.minecraft.world.item.crafting.Ingredient;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.damagesource.DamageSource;

import net.mcreator.mileswilletttangy.init.MilesWillettTangyModItems;

import java.util.List;

public class TangyenchantmentEnchantment extends Enchantment {
	public TangyenchantmentEnchantment(EquipmentSlot... slots) {
		super(Enchantment.Rarity.VERY_RARE, EnchantmentCategory.WEAPON, slots);
	}

	@Override
	public int getMinLevel() {
		return 250;
	}

	@Override
	public int getMaxLevel() {
		return 500;
	}

	@Override
	public int getDamageProtection(int level, DamageSource source) {
		return level * 600;
	}

	@Override
	protected boolean checkCompatibility(Enchantment ench) {
		return List.of(Enchantments.SHARPNESS, Enchantments.FIRE_ASPECT, Enchantments.KNOCKBACK, Enchantments.SMITE).contains(ench);
	}

	@Override
	public boolean canApplyAtEnchantingTable(ItemStack itemstack) {
		return Ingredient.of(new ItemStack(MilesWillettTangyModItems.SWORDOFTHETIGER.get()), new ItemStack(Items.DIAMOND_SWORD), new ItemStack(Items.NETHERITE_SWORD), new ItemStack(Items.GOLDEN_SWORD), new ItemStack(Items.IRON_SWORD))
				.test(itemstack);
	}

	@Override
	public boolean isTreasureOnly() {
		return true;
	}
}

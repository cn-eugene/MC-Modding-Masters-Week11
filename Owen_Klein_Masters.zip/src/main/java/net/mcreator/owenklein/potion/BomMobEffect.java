
package net.mcreator.owenklein.potion;

import net.minecraft.world.entity.ai.attributes.AttributeMap;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.effect.MobEffectCategory;
import net.minecraft.world.effect.MobEffect;

import net.mcreator.owenklein.procedures.ExpodeProjectileHitsLivingEntityProcedure;

public class BomMobEffect extends MobEffect {
	public BomMobEffect() {
		super(MobEffectCategory.HARMFUL, -16777216);
	}

	@Override
	public void removeAttributeModifiers(LivingEntity entity, AttributeMap attributeMap, int amplifier) {
		super.removeAttributeModifiers(entity, attributeMap, amplifier);
		ExpodeProjectileHitsLivingEntityProcedure.execute(entity.level(), entity.getX(), entity.getY(), entity.getZ());
	}

	@Override
	public boolean isDurationEffectTick(int duration, int amplifier) {
		return true;
	}
}


package net.mcreator.owenklein.item;

import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.Item;

public class BoltTexItem extends Item {
	public BoltTexItem() {
		super(new Item.Properties().stacksTo(64).rarity(Rarity.COMMON));
	}
}

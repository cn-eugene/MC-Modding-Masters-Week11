
package net.mcreator.owenklein.enchantment;

import net.minecraft.world.item.enchantment.EnchantmentCategory;
import net.minecraft.world.item.enchantment.Enchantment;
import net.minecraft.world.entity.EquipmentSlot;

public class StrikingEnchantment extends Enchantment {
	public StrikingEnchantment(EquipmentSlot... slots) {
		super(Enchantment.Rarity.VERY_RARE, EnchantmentCategory.BREAKABLE, slots);
	}

	@Override
	public int getMinLevel() {
		return 3;
	}

	@Override
	public int getMaxLevel() {
		return 3;
	}
}

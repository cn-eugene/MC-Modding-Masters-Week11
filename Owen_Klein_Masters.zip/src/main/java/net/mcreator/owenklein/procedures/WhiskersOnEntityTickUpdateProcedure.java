package net.mcreator.owenklein.procedures;

import net.minecraft.world.phys.Vec3;
import net.minecraft.world.entity.Entity;

public class WhiskersOnEntityTickUpdateProcedure {
	public static void execute(Entity entity) {
		if (entity == null)
			return;
		if (entity.getPersistentData().getBoolean("sitting")) {
			entity.setDeltaMovement(new Vec3(0, 0, 0));
		}
	}
}

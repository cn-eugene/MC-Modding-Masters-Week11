package net.mcreator.owenklein.procedures;

import net.minecraft.world.entity.Entity;

public class WhiskersRightClickedOnEntityProcedure {
	public static void execute(Entity entity) {
		if (entity == null)
			return;
		if (entity.getPersistentData().getBoolean("sitting")) {
			entity.getPersistentData().putBoolean("sitting", true);
		} else {
			entity.getPersistentData().putBoolean("sitting", false);
		}
	}
}

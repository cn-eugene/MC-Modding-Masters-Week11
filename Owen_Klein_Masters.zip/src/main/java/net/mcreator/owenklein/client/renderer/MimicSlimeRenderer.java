
package net.mcreator.owenklein.client.renderer;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.model.geom.ModelLayers;
import net.minecraft.client.model.SlimeModel;

import net.mcreator.owenklein.entity.MimicSlimeEntity;

import com.mojang.blaze3d.vertex.PoseStack;

public class MimicSlimeRenderer extends MobRenderer<MimicSlimeEntity, SlimeModel<MimicSlimeEntity>> {
	public MimicSlimeRenderer(EntityRendererProvider.Context context) {
		super(context, new SlimeModel(context.bakeLayer(ModelLayers.SLIME)), 0.5f);
	}

	@Override
	protected void scale(MimicSlimeEntity entity, PoseStack poseStack, float f) {
		poseStack.scale(1.5f, 1.5f, 1.5f);
	}

	@Override
	public ResourceLocation getTextureLocation(MimicSlimeEntity entity) {
		return new ResourceLocation("owen_klein:textures/entities/slime_block_mimic.png");
	}
}

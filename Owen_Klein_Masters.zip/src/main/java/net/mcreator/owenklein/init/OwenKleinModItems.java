
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.owenklein.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.common.ForgeSpawnEggItem;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.DoubleHighBlockItem;
import net.minecraft.world.item.BlockItem;

import net.mcreator.owenklein.item.SlimeSitheItem;
import net.mcreator.owenklein.item.PizzaItem;
import net.mcreator.owenklein.item.GooOreItem;
import net.mcreator.owenklein.item.BoltTexItem;
import net.mcreator.owenklein.OwenKleinMod;

public class OwenKleinModItems {
	public static final DeferredRegister<Item> REGISTRY = DeferredRegister.create(ForgeRegistries.ITEMS, OwenKleinMod.MODID);
	public static final RegistryObject<Item> GOO_ORE = REGISTRY.register("goo_ore", () -> new GooOreItem());
	public static final RegistryObject<Item> GOO = block(OwenKleinModBlocks.GOO);
	public static final RegistryObject<Item> SLIME_SITHE = REGISTRY.register("slime_sithe", () -> new SlimeSitheItem());
	public static final RegistryObject<Item> WARN = block(OwenKleinModBlocks.WARN);
	public static final RegistryObject<Item> BOLT_TEX = REGISTRY.register("bolt_tex", () -> new BoltTexItem());
	public static final RegistryObject<Item> WHISKERS_SPAWN_EGG = REGISTRY.register("whiskers_spawn_egg", () -> new ForgeSpawnEggItem(OwenKleinModEntities.WHISKERS, -16777216, -1, new Item.Properties()));
	public static final RegistryObject<Item> MIMIC_SLIME_SPAWN_EGG = REGISTRY.register("mimic_slime_spawn_egg", () -> new ForgeSpawnEggItem(OwenKleinModEntities.MIMIC_SLIME, -13434880, -16751104, new Item.Properties()));
	public static final RegistryObject<Item> PIZZA = REGISTRY.register("pizza", () -> new PizzaItem());
	public static final RegistryObject<Item> SPORE_GRASS = block(OwenKleinModBlocks.SPORE_GRASS);
	public static final RegistryObject<Item> SPORE_TREE = block(OwenKleinModBlocks.SPORE_TREE);
	public static final RegistryObject<Item> SPORE_LEAVES = block(OwenKleinModBlocks.SPORE_LEAVES);
	public static final RegistryObject<Item> SPORE_DIRT = block(OwenKleinModBlocks.SPORE_DIRT);
	public static final RegistryObject<Item> SPORE_SAND = block(OwenKleinModBlocks.SPORE_SAND);
	public static final RegistryObject<Item> SPORE_GRASSN = block(OwenKleinModBlocks.SPORE_GRASSN);
	public static final RegistryObject<Item> SPORE_PLANKS = block(OwenKleinModBlocks.SPORE_PLANKS);
	public static final RegistryObject<Item> SPORE_PLANK_STAIRS = block(OwenKleinModBlocks.SPORE_PLANK_STAIRS);
	public static final RegistryObject<Item> SPORE_PRESSURE_PLATE = block(OwenKleinModBlocks.SPORE_PRESSURE_PLATE);
	public static final RegistryObject<Item> SPORE_PLANK_SLAB = block(OwenKleinModBlocks.SPORE_PLANK_SLAB);
	public static final RegistryObject<Item> SPORE_BUTTON = block(OwenKleinModBlocks.SPORE_BUTTON);
	public static final RegistryObject<Item> SPORE_FENCE = block(OwenKleinModBlocks.SPORE_FENCE);
	public static final RegistryObject<Item> SPORE_FENCE_GATE = block(OwenKleinModBlocks.SPORE_FENCE_GATE);
	public static final RegistryObject<Item> SPORE_DOOR = doubleBlock(OwenKleinModBlocks.SPORE_DOOR);
	public static final RegistryObject<Item> SPORE_TRAPDOOR = block(OwenKleinModBlocks.SPORE_TRAPDOOR);

	// Start of user code block custom items
	// End of user code block custom items
	private static RegistryObject<Item> block(RegistryObject<Block> block) {
		return REGISTRY.register(block.getId().getPath(), () -> new BlockItem(block.get(), new Item.Properties()));
	}

	private static RegistryObject<Item> doubleBlock(RegistryObject<Block> block) {
		return REGISTRY.register(block.getId().getPath(), () -> new DoubleHighBlockItem(block.get(), new Item.Properties()));
	}
}

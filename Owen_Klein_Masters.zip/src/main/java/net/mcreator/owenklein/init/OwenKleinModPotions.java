
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.owenklein.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.item.alchemy.Potion;
import net.minecraft.world.effect.MobEffectInstance;

import net.mcreator.owenklein.OwenKleinMod;

public class OwenKleinModPotions {
	public static final DeferredRegister<Potion> REGISTRY = DeferredRegister.create(ForgeRegistries.POTIONS, OwenKleinMod.MODID);
	public static final RegistryObject<Potion> BOMPOTION = REGISTRY.register("bompotion", () -> new Potion(new MobEffectInstance(OwenKleinModMobEffects.BOM.get(), 600, 0, false, true)));
	public static final RegistryObject<Potion> BEER = REGISTRY.register("beer", () -> new Potion(new MobEffectInstance(OwenKleinModMobEffects.DRUNK.get(), 1000, 5, false, true)));
	public static final RegistryObject<Potion> LIGHNTING = REGISTRY.register("lighnting", () -> new Potion(new MobEffectInstance(OwenKleinModMobEffects.LIGHTNING.get(), 300, 5, false, false)));
	public static final RegistryObject<Potion> FLIPPED = REGISTRY.register("flipped", () -> new Potion(new MobEffectInstance(OwenKleinModMobEffects.FLIP.get(), 1, 0, false, false)));
}

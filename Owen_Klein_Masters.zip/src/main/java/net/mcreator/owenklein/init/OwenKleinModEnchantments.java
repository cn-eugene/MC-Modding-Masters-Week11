
/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.owenklein.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.item.enchantment.Enchantment;

import net.mcreator.owenklein.enchantment.StrikingEnchantment;
import net.mcreator.owenklein.enchantment.StreakingEnchantment;
import net.mcreator.owenklein.OwenKleinMod;

public class OwenKleinModEnchantments {
	public static final DeferredRegister<Enchantment> REGISTRY = DeferredRegister.create(ForgeRegistries.ENCHANTMENTS, OwenKleinMod.MODID);
	public static final RegistryObject<Enchantment> STRIKING = REGISTRY.register("striking", () -> new StrikingEnchantment());
	public static final RegistryObject<Enchantment> STREAKING = REGISTRY.register("streaking", () -> new StreakingEnchantment());
}

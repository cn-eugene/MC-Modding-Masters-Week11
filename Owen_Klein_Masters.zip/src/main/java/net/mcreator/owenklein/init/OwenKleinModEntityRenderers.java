
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.owenklein.init;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.api.distmarker.Dist;

import net.minecraft.client.renderer.entity.ThrownItemRenderer;

import net.mcreator.owenklein.client.renderer.WhiskersRenderer;
import net.mcreator.owenklein.client.renderer.MimicSlimeRenderer;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public class OwenKleinModEntityRenderers {
	@SubscribeEvent
	public static void registerEntityRenderers(EntityRenderersEvent.RegisterRenderers event) {
		event.registerEntityRenderer(OwenKleinModEntities.EXPODE.get(), ThrownItemRenderer::new);
		event.registerEntityRenderer(OwenKleinModEntities.BOLT.get(), ThrownItemRenderer::new);
		event.registerEntityRenderer(OwenKleinModEntities.WHISKERS.get(), WhiskersRenderer::new);
		event.registerEntityRenderer(OwenKleinModEntities.MIMIC_SLIME.get(), MimicSlimeRenderer::new);
		event.registerEntityRenderer(OwenKleinModEntities.MIMIC_SLIME_PROJECTILE.get(), ThrownItemRenderer::new);
	}
}

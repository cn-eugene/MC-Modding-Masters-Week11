
/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.owenklein.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.effect.MobEffect;

import net.mcreator.owenklein.potion.LightningMobEffect;
import net.mcreator.owenklein.potion.FlipMobEffect;
import net.mcreator.owenklein.potion.DrunkMobEffect;
import net.mcreator.owenklein.potion.BomMobEffect;
import net.mcreator.owenklein.OwenKleinMod;

public class OwenKleinModMobEffects {
	public static final DeferredRegister<MobEffect> REGISTRY = DeferredRegister.create(ForgeRegistries.MOB_EFFECTS, OwenKleinMod.MODID);
	public static final RegistryObject<MobEffect> BOM = REGISTRY.register("bom", () -> new BomMobEffect());
	public static final RegistryObject<MobEffect> DRUNK = REGISTRY.register("drunk", () -> new DrunkMobEffect());
	public static final RegistryObject<MobEffect> LIGHTNING = REGISTRY.register("lightning", () -> new LightningMobEffect());
	public static final RegistryObject<MobEffect> FLIP = REGISTRY.register("flip", () -> new FlipMobEffect());
}

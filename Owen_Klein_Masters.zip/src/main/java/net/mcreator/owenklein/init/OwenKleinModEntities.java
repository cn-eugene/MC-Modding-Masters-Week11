
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.owenklein.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.event.entity.EntityAttributeCreationEvent;

import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Entity;

import net.mcreator.owenklein.entity.WhiskersEntity;
import net.mcreator.owenklein.entity.MimicSlimeEntityProjectile;
import net.mcreator.owenklein.entity.MimicSlimeEntity;
import net.mcreator.owenklein.entity.ExpodeEntity;
import net.mcreator.owenklein.entity.BoltEntity;
import net.mcreator.owenklein.OwenKleinMod;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD)
public class OwenKleinModEntities {
	public static final DeferredRegister<EntityType<?>> REGISTRY = DeferredRegister.create(ForgeRegistries.ENTITY_TYPES, OwenKleinMod.MODID);
	public static final RegistryObject<EntityType<ExpodeEntity>> EXPODE = register("expode",
			EntityType.Builder.<ExpodeEntity>of(ExpodeEntity::new, MobCategory.MISC).setCustomClientFactory(ExpodeEntity::new).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(1).sized(0.5f, 0.5f));
	public static final RegistryObject<EntityType<BoltEntity>> BOLT = register("bolt",
			EntityType.Builder.<BoltEntity>of(BoltEntity::new, MobCategory.MISC).setCustomClientFactory(BoltEntity::new).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(1).sized(0.5f, 0.5f));
	public static final RegistryObject<EntityType<WhiskersEntity>> WHISKERS = register("whiskers",
			EntityType.Builder.<WhiskersEntity>of(WhiskersEntity::new, MobCategory.CREATURE).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(3).setCustomClientFactory(WhiskersEntity::new).fireImmune().sized(0.6f, 0.7f));
	public static final RegistryObject<EntityType<MimicSlimeEntity>> MIMIC_SLIME = register("mimic_slime",
			EntityType.Builder.<MimicSlimeEntity>of(MimicSlimeEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(3).setCustomClientFactory(MimicSlimeEntity::new)

					.sized(0.6f, 0.6f));
	public static final RegistryObject<EntityType<MimicSlimeEntityProjectile>> MIMIC_SLIME_PROJECTILE = register("projectile_mimic_slime", EntityType.Builder.<MimicSlimeEntityProjectile>of(MimicSlimeEntityProjectile::new, MobCategory.MISC)
			.setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(1).setCustomClientFactory(MimicSlimeEntityProjectile::new).sized(0.5f, 0.5f));

	private static <T extends Entity> RegistryObject<EntityType<T>> register(String registryname, EntityType.Builder<T> entityTypeBuilder) {
		return REGISTRY.register(registryname, () -> (EntityType<T>) entityTypeBuilder.build(registryname));
	}

	@SubscribeEvent
	public static void init(FMLCommonSetupEvent event) {
		event.enqueueWork(() -> {
			WhiskersEntity.init();
			MimicSlimeEntity.init();
		});
	}

	@SubscribeEvent
	public static void registerAttributes(EntityAttributeCreationEvent event) {
		event.put(WHISKERS.get(), WhiskersEntity.createAttributes().build());
		event.put(MIMIC_SLIME.get(), MimicSlimeEntity.createAttributes().build());
	}
}

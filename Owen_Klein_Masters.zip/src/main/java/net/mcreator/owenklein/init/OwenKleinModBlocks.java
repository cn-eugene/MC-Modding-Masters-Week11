
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.owenklein.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.level.block.Block;

import net.mcreator.owenklein.block.WarnBlock;
import net.mcreator.owenklein.block.SporeTreeBlock;
import net.mcreator.owenklein.block.SporeTrapdoorBlock;
import net.mcreator.owenklein.block.SporeSandBlock;
import net.mcreator.owenklein.block.SporePressurePlateBlock;
import net.mcreator.owenklein.block.SporePlanksBlock;
import net.mcreator.owenklein.block.SporePlankStairsBlock;
import net.mcreator.owenklein.block.SporePlankSlabBlock;
import net.mcreator.owenklein.block.SporeLeavesBlock;
import net.mcreator.owenklein.block.SporeGrassnBlock;
import net.mcreator.owenklein.block.SporeGrassBlock;
import net.mcreator.owenklein.block.SporeFenceGateBlock;
import net.mcreator.owenklein.block.SporeFenceBlock;
import net.mcreator.owenklein.block.SporeDoorBlock;
import net.mcreator.owenklein.block.SporeDirtBlock;
import net.mcreator.owenklein.block.SporeButtonBlock;
import net.mcreator.owenklein.block.GooBlock;
import net.mcreator.owenklein.OwenKleinMod;

public class OwenKleinModBlocks {
	public static final DeferredRegister<Block> REGISTRY = DeferredRegister.create(ForgeRegistries.BLOCKS, OwenKleinMod.MODID);
	public static final RegistryObject<Block> GOO = REGISTRY.register("goo", () -> new GooBlock());
	public static final RegistryObject<Block> WARN = REGISTRY.register("warn", () -> new WarnBlock());
	public static final RegistryObject<Block> SPORE_GRASS = REGISTRY.register("spore_grass", () -> new SporeGrassBlock());
	public static final RegistryObject<Block> SPORE_TREE = REGISTRY.register("spore_tree", () -> new SporeTreeBlock());
	public static final RegistryObject<Block> SPORE_LEAVES = REGISTRY.register("spore_leaves", () -> new SporeLeavesBlock());
	public static final RegistryObject<Block> SPORE_DIRT = REGISTRY.register("spore_dirt", () -> new SporeDirtBlock());
	public static final RegistryObject<Block> SPORE_SAND = REGISTRY.register("spore_sand", () -> new SporeSandBlock());
	public static final RegistryObject<Block> SPORE_GRASSN = REGISTRY.register("spore_grassn", () -> new SporeGrassnBlock());
	public static final RegistryObject<Block> SPORE_PLANKS = REGISTRY.register("spore_planks", () -> new SporePlanksBlock());
	public static final RegistryObject<Block> SPORE_PLANK_STAIRS = REGISTRY.register("spore_plank_stairs", () -> new SporePlankStairsBlock());
	public static final RegistryObject<Block> SPORE_PRESSURE_PLATE = REGISTRY.register("spore_pressure_plate", () -> new SporePressurePlateBlock());
	public static final RegistryObject<Block> SPORE_PLANK_SLAB = REGISTRY.register("spore_plank_slab", () -> new SporePlankSlabBlock());
	public static final RegistryObject<Block> SPORE_BUTTON = REGISTRY.register("spore_button", () -> new SporeButtonBlock());
	public static final RegistryObject<Block> SPORE_FENCE = REGISTRY.register("spore_fence", () -> new SporeFenceBlock());
	public static final RegistryObject<Block> SPORE_FENCE_GATE = REGISTRY.register("spore_fence_gate", () -> new SporeFenceGateBlock());
	public static final RegistryObject<Block> SPORE_DOOR = REGISTRY.register("spore_door", () -> new SporeDoorBlock());
	public static final RegistryObject<Block> SPORE_TRAPDOOR = REGISTRY.register("spore_trapdoor", () -> new SporeTrapdoorBlock());
	// Start of user code block custom blocks
	// End of user code block custom blocks
}


/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.wellington.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.item.enchantment.Enchantment;

import net.mcreator.wellington.enchantment.LightningEnchantment;
import net.mcreator.wellington.WellingtonMod;

public class WellingtonModEnchantments {
	public static final DeferredRegister<Enchantment> REGISTRY = DeferredRegister.create(ForgeRegistries.ENCHANTMENTS, WellingtonMod.MODID);
	public static final RegistryObject<Enchantment> LIGHTNING = REGISTRY.register("lightning", () -> new LightningEnchantment());
}


/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.wellington.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.effect.MobEffect;

import net.mcreator.wellington.potion.BombeffectMobEffect;
import net.mcreator.wellington.WellingtonMod;

public class WellingtonModMobEffects {
	public static final DeferredRegister<MobEffect> REGISTRY = DeferredRegister.create(ForgeRegistries.MOB_EFFECTS, WellingtonMod.MODID);
	public static final RegistryObject<MobEffect> BOMBEFFECT = REGISTRY.register("bombeffect", () -> new BombeffectMobEffect());
}


/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.wellington.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.item.alchemy.Potion;
import net.minecraft.world.effect.MobEffectInstance;

import net.mcreator.wellington.WellingtonMod;

public class WellingtonModPotions {
	public static final DeferredRegister<Potion> REGISTRY = DeferredRegister.create(ForgeRegistries.POTIONS, WellingtonMod.MODID);
	public static final RegistryObject<Potion> BOMBPOTION = REGISTRY.register("bombpotion", () -> new Potion(new MobEffectInstance(WellingtonModMobEffects.BOMBEFFECT.get(), 3600, 0, false, true)));
}

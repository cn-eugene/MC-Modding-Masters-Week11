
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.wellington.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.BlockItem;

import net.mcreator.wellington.item.RubyswordItem;
import net.mcreator.wellington.item.RubyItem;
import net.mcreator.wellington.item.JumpsuitItem;
import net.mcreator.wellington.item.BowwItem;
import net.mcreator.wellington.item.BoomerangItem;
import net.mcreator.wellington.WellingtonMod;

public class WellingtonModItems {
	public static final DeferredRegister<Item> REGISTRY = DeferredRegister.create(ForgeRegistries.ITEMS, WellingtonMod.MODID);
	public static final RegistryObject<Item> RUBY = REGISTRY.register("ruby", () -> new RubyItem());
	public static final RegistryObject<Item> RUBYORE = block(WellingtonModBlocks.RUBYORE);
	public static final RegistryObject<Item> RUBYSWORD = REGISTRY.register("rubysword", () -> new RubyswordItem());
	public static final RegistryObject<Item> BOWW = REGISTRY.register("boww", () -> new BowwItem());
	public static final RegistryObject<Item> BOOMERANG = REGISTRY.register("boomerang", () -> new BoomerangItem());
	public static final RegistryObject<Item> JUMPSUIT_HELMET = REGISTRY.register("jumpsuit_helmet", () -> new JumpsuitItem.Helmet());
	public static final RegistryObject<Item> JUMPSUIT_CHESTPLATE = REGISTRY.register("jumpsuit_chestplate", () -> new JumpsuitItem.Chestplate());
	public static final RegistryObject<Item> JUMPSUIT_LEGGINGS = REGISTRY.register("jumpsuit_leggings", () -> new JumpsuitItem.Leggings());
	public static final RegistryObject<Item> JUMPSUIT_BOOTS = REGISTRY.register("jumpsuit_boots", () -> new JumpsuitItem.Boots());

	// Start of user code block custom items
	// End of user code block custom items
	private static RegistryObject<Item> block(RegistryObject<Block> block) {
		return REGISTRY.register(block.getId().getPath(), () -> new BlockItem(block.get(), new Item.Properties()));
	}
}

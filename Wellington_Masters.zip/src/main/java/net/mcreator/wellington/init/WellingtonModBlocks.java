
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.wellington.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.level.block.Block;

import net.mcreator.wellington.block.RubyoreBlock;
import net.mcreator.wellington.WellingtonMod;

public class WellingtonModBlocks {
	public static final DeferredRegister<Block> REGISTRY = DeferredRegister.create(ForgeRegistries.BLOCKS, WellingtonMod.MODID);
	public static final RegistryObject<Block> RUBYORE = REGISTRY.register("rubyore", () -> new RubyoreBlock());
	// Start of user code block custom blocks
	// End of user code block custom blocks
}


/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.ephraimfletcher.init;

import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.event.BuildCreativeModeTabContentsEvent;

import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.core.registries.Registries;

import net.mcreator.ephraimfletcher.EphraimFletcherMod;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD)
public class EphraimFletcherModTabs {
	public static final DeferredRegister<CreativeModeTab> REGISTRY = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, EphraimFletcherMod.MODID);

	@SubscribeEvent
	public static void buildTabContentsVanilla(BuildCreativeModeTabContentsEvent tabData) {
		if (tabData.getTabKey() == CreativeModeTabs.FUNCTIONAL_BLOCKS) {
			tabData.accept(EphraimFletcherModBlocks.TRIPWIREBOMB.get().asItem());
		} else if (tabData.getTabKey() == CreativeModeTabs.COMBAT) {
			tabData.accept(EphraimFletcherModItems.BLADE.get());
			tabData.accept(EphraimFletcherModItems.GRAVITYARMOUR_HELMET.get());
			tabData.accept(EphraimFletcherModItems.GRAVITYARMOUR_CHESTPLATE.get());
			tabData.accept(EphraimFletcherModItems.GRAVITYARMOUR_LEGGINGS.get());
			tabData.accept(EphraimFletcherModItems.GRAVITYARMOUR_BOOTS.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.INGREDIENTS) {
			tabData.accept(EphraimFletcherModItems.SILVER.get());
			tabData.accept(EphraimFletcherModItems.SILVERINGOT.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.NATURAL_BLOCKS) {
			tabData.accept(EphraimFletcherModBlocks.SILVER_BLOCK.get().asItem());
			tabData.accept(EphraimFletcherModBlocks.SILVERWOOD.get().asItem());
		} else if (tabData.getTabKey() == CreativeModeTabs.TOOLS_AND_UTILITIES) {
			tabData.accept(EphraimFletcherModItems.SILVERSWORD.get());
			tabData.accept(EphraimFletcherModItems.SILVERSYTHE.get());
		}
	}
}

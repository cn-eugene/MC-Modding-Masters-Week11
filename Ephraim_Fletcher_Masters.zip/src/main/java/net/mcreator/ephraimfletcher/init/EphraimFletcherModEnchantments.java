
/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.ephraimfletcher.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.item.enchantment.Enchantment;

import net.mcreator.ephraimfletcher.enchantment.ElectricalswordEnchantment;
import net.mcreator.ephraimfletcher.EphraimFletcherMod;

public class EphraimFletcherModEnchantments {
	public static final DeferredRegister<Enchantment> REGISTRY = DeferredRegister.create(ForgeRegistries.ENCHANTMENTS, EphraimFletcherMod.MODID);
	public static final RegistryObject<Enchantment> ELECTRICALSWORD = REGISTRY.register("electricalsword", () -> new ElectricalswordEnchantment());
}

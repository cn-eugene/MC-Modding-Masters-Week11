
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.ephraimfletcher.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.level.block.Block;

import net.mcreator.ephraimfletcher.block.TripwirebombBlock;
import net.mcreator.ephraimfletcher.block.SilverwoodBlock;
import net.mcreator.ephraimfletcher.block.SilvergrassBlock;
import net.mcreator.ephraimfletcher.block.SilverBlockBlock;
import net.mcreator.ephraimfletcher.EphraimFletcherMod;

public class EphraimFletcherModBlocks {
	public static final DeferredRegister<Block> REGISTRY = DeferredRegister.create(ForgeRegistries.BLOCKS, EphraimFletcherMod.MODID);
	public static final RegistryObject<Block> SILVER_BLOCK = REGISTRY.register("silver_block", () -> new SilverBlockBlock());
	public static final RegistryObject<Block> TRIPWIREBOMB = REGISTRY.register("tripwirebomb", () -> new TripwirebombBlock());
	public static final RegistryObject<Block> SILVERWOOD = REGISTRY.register("silverwood", () -> new SilverwoodBlock());
	public static final RegistryObject<Block> SILVERGRASS = REGISTRY.register("silvergrass", () -> new SilvergrassBlock());
	// Start of user code block custom blocks
	// End of user code block custom blocks
}


/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.ephraimfletcher.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.BlockItem;

import net.mcreator.ephraimfletcher.item.SilversytheItem;
import net.mcreator.ephraimfletcher.item.SilverswordItem;
import net.mcreator.ephraimfletcher.item.SilveringotItem;
import net.mcreator.ephraimfletcher.item.SilverItem;
import net.mcreator.ephraimfletcher.item.GravityarmourItem;
import net.mcreator.ephraimfletcher.item.BladeItem;
import net.mcreator.ephraimfletcher.EphraimFletcherMod;

public class EphraimFletcherModItems {
	public static final DeferredRegister<Item> REGISTRY = DeferredRegister.create(ForgeRegistries.ITEMS, EphraimFletcherMod.MODID);
	public static final RegistryObject<Item> SILVER = REGISTRY.register("silver", () -> new SilverItem());
	public static final RegistryObject<Item> SILVER_BLOCK = block(EphraimFletcherModBlocks.SILVER_BLOCK);
	public static final RegistryObject<Item> SILVERINGOT = REGISTRY.register("silveringot", () -> new SilveringotItem());
	public static final RegistryObject<Item> SILVERSWORD = REGISTRY.register("silversword", () -> new SilverswordItem());
	public static final RegistryObject<Item> BLADE = REGISTRY.register("blade", () -> new BladeItem());
	public static final RegistryObject<Item> TRIPWIREBOMB = block(EphraimFletcherModBlocks.TRIPWIREBOMB);
	public static final RegistryObject<Item> SILVERSYTHE = REGISTRY.register("silversythe", () -> new SilversytheItem());
	public static final RegistryObject<Item> GRAVITYARMOUR_HELMET = REGISTRY.register("gravityarmour_helmet", () -> new GravityarmourItem.Helmet());
	public static final RegistryObject<Item> GRAVITYARMOUR_CHESTPLATE = REGISTRY.register("gravityarmour_chestplate", () -> new GravityarmourItem.Chestplate());
	public static final RegistryObject<Item> GRAVITYARMOUR_LEGGINGS = REGISTRY.register("gravityarmour_leggings", () -> new GravityarmourItem.Leggings());
	public static final RegistryObject<Item> GRAVITYARMOUR_BOOTS = REGISTRY.register("gravityarmour_boots", () -> new GravityarmourItem.Boots());
	public static final RegistryObject<Item> SILVERWOOD = block(EphraimFletcherModBlocks.SILVERWOOD);
	public static final RegistryObject<Item> SILVERGRASS = block(EphraimFletcherModBlocks.SILVERGRASS);

	// Start of user code block custom items
	// End of user code block custom items
	private static RegistryObject<Item> block(RegistryObject<Block> block) {
		return REGISTRY.register(block.getId().getPath(), () -> new BlockItem(block.get(), new Item.Properties()));
	}
}

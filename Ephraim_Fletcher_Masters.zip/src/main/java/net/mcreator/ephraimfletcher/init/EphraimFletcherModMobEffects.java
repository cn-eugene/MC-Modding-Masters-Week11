
/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.ephraimfletcher.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.effect.MobEffect;

import net.mcreator.ephraimfletcher.potion.BombinabottleMobEffect;
import net.mcreator.ephraimfletcher.EphraimFletcherMod;

public class EphraimFletcherModMobEffects {
	public static final DeferredRegister<MobEffect> REGISTRY = DeferredRegister.create(ForgeRegistries.MOB_EFFECTS, EphraimFletcherMod.MODID);
	public static final RegistryObject<MobEffect> BOMBINABOTTLE = REGISTRY.register("bombinabottle", () -> new BombinabottleMobEffect());
}

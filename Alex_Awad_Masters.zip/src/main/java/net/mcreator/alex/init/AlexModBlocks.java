
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.alex.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.level.block.Block;

import net.mcreator.alex.block.LOGGBlock;
import net.mcreator.alex.block.GRASSYBlock;
import net.mcreator.alex.block.GODDIMENSIONPortalBlock;
import net.mcreator.alex.block.GODBLOCKOREBlock;
import net.mcreator.alex.block.GOD10NTBlock;
import net.mcreator.alex.AlexMod;

public class AlexModBlocks {
	public static final DeferredRegister<Block> REGISTRY = DeferredRegister.create(ForgeRegistries.BLOCKS, AlexMod.MODID);
	public static final RegistryObject<Block> GODBLOCKORE = REGISTRY.register("godblockore", () -> new GODBLOCKOREBlock());
	public static final RegistryObject<Block> GODDIMENSION_PORTAL = REGISTRY.register("goddimension_portal", () -> new GODDIMENSIONPortalBlock());
	public static final RegistryObject<Block> GOD_10_NT = REGISTRY.register("god_10_nt", () -> new GOD10NTBlock());
	public static final RegistryObject<Block> GRASSY = REGISTRY.register("grassy", () -> new GRASSYBlock());
	public static final RegistryObject<Block> LOGG = REGISTRY.register("logg", () -> new LOGGBlock());
	// Start of user code block custom blocks
	// End of user code block custom blocks
}

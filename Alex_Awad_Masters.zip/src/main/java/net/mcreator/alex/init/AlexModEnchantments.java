
/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.alex.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.item.enchantment.Enchantment;

import net.mcreator.alex.enchantment.REFLECTIONOFDAMAGEEnchantment;
import net.mcreator.alex.enchantment.ICANTLOSELIKETISEnchantment;
import net.mcreator.alex.AlexMod;

public class AlexModEnchantments {
	public static final DeferredRegister<Enchantment> REGISTRY = DeferredRegister.create(ForgeRegistries.ENCHANTMENTS, AlexMod.MODID);
	public static final RegistryObject<Enchantment> REFLECTIONOFDAMAGE = REGISTRY.register("reflectionofdamage", () -> new REFLECTIONOFDAMAGEEnchantment());
	public static final RegistryObject<Enchantment> ICANTLOSELIKETIS = REGISTRY.register("icantloseliketis", () -> new ICANTLOSELIKETISEnchantment());
}

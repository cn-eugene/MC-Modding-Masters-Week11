
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.alex.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.common.ForgeSpawnEggItem;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.BlockItem;

import net.mcreator.alex.item.GODINGOTItem;
import net.mcreator.alex.item.GODDIMENSIONItem;
import net.mcreator.alex.item.GODAXEItem;
import net.mcreator.alex.item.GODARMORItem;
import net.mcreator.alex.AlexMod;

public class AlexModItems {
	public static final DeferredRegister<Item> REGISTRY = DeferredRegister.create(ForgeRegistries.ITEMS, AlexMod.MODID);
	public static final RegistryObject<Item> GODAXE = REGISTRY.register("godaxe", () -> new GODAXEItem());
	public static final RegistryObject<Item> GODARMOR_HELMET = REGISTRY.register("godarmor_helmet", () -> new GODARMORItem.Helmet());
	public static final RegistryObject<Item> GODARMOR_CHESTPLATE = REGISTRY.register("godarmor_chestplate", () -> new GODARMORItem.Chestplate());
	public static final RegistryObject<Item> GODARMOR_LEGGINGS = REGISTRY.register("godarmor_leggings", () -> new GODARMORItem.Leggings());
	public static final RegistryObject<Item> GODARMOR_BOOTS = REGISTRY.register("godarmor_boots", () -> new GODARMORItem.Boots());
	public static final RegistryObject<Item> GODBLOCKORE = block(AlexModBlocks.GODBLOCKORE);
	public static final RegistryObject<Item> GODINGOT = REGISTRY.register("godingot", () -> new GODINGOTItem());
	public static final RegistryObject<Item> GODDIMENSION = REGISTRY.register("goddimension", () -> new GODDIMENSIONItem());
	public static final RegistryObject<Item> GOD_10_NT = block(AlexModBlocks.GOD_10_NT);
	public static final RegistryObject<Item> SPIDERSTEVE_SPAWN_EGG = REGISTRY.register("spidersteve_spawn_egg", () -> new ForgeSpawnEggItem(AlexModEntities.SPIDERSTEVE, -16776961, -16711681, new Item.Properties()));
	public static final RegistryObject<Item> GRASSY = block(AlexModBlocks.GRASSY);
	public static final RegistryObject<Item> LOGG = block(AlexModBlocks.LOGG);

	// Start of user code block custom items
	// End of user code block custom items
	private static RegistryObject<Item> block(RegistryObject<Block> block) {
		return REGISTRY.register(block.getId().getPath(), () -> new BlockItem(block.get(), new Item.Properties()));
	}
}


/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.alex.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.effect.MobEffect;

import net.mcreator.alex.potion.POTIONOFARROWSMobEffect;
import net.mcreator.alex.AlexMod;

public class AlexModMobEffects {
	public static final DeferredRegister<MobEffect> REGISTRY = DeferredRegister.create(ForgeRegistries.MOB_EFFECTS, AlexMod.MODID);
	public static final RegistryObject<MobEffect> POTIONOFARROWS = REGISTRY.register("potionofarrows", () -> new POTIONOFARROWSMobEffect());
}

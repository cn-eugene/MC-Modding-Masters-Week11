
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.alex.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.item.alchemy.Potion;
import net.minecraft.world.effect.MobEffectInstance;

import net.mcreator.alex.AlexMod;

public class AlexModPotions {
	public static final DeferredRegister<Potion> REGISTRY = DeferredRegister.create(ForgeRegistries.POTIONS, AlexMod.MODID);
	public static final RegistryObject<Potion> POTIONOFFARROWS = REGISTRY.register("potionoffarrows", () -> new Potion(new MobEffectInstance(AlexModMobEffects.POTIONOFARROWS.get(), 1200, 255, false, false)));
}


package net.mcreator.alex.block;

import org.checkerframework.checker.units.qual.s;

import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.item.PickaxeItem;
import net.minecraft.world.entity.player.Player;
import net.minecraft.core.BlockPos;

public class GODBLOCKOREBlock extends Block {
	public GODBLOCKOREBlock() {
		super(BlockBehaviour.Properties.of().sound(SoundType.GRAVEL).strength(64000f, 1000000f).lightLevel(s -> 15).requiresCorrectToolForDrops().friction(5f).speedFactor(999f).jumpFactor(999f));
	}

	@Override
	public int getLightBlock(BlockState state, BlockGetter worldIn, BlockPos pos) {
		return 15;
	}

	@Override
	public boolean canHarvestBlock(BlockState state, BlockGetter world, BlockPos pos, Player player) {
		if (player.getInventory().getSelected().getItem() instanceof PickaxeItem tieredItem)
			return tieredItem.getTier().getLevel() >= 10;
		else
			return super.canHarvestBlock(state, world, pos, player);
	}
}
